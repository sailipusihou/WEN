exports.id=2502,exports.ids=[2502],exports.modules={96487:()=>{},78335:()=>{},32979:(e,t,r)=>{"use strict";r.d(t,{CK:()=>l,DI:()=>s,Kv:()=>d,ZM:()=>a,dV:()=>c});var o=r(98721),n=r(20351);function i(e){return String(e).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}async function a(e){let t=(0,n.TM)().settings.get();if(!t.smtpHost||!t.smtpUser||!t.smtpPass)return{success:!1,error:"SMTP not configured"};try{let r=o.createTransport({host:t.smtpHost,port:Number(t.smtpPort)||587,secure:465===Number(t.smtpPort),auth:{user:t.smtpUser,pass:t.smtpPass}}),n=t.smtpFromEmail||t.smtpUser,i=t.smtpReplyTo||t.smtpFromEmail||void 0;return await r.sendMail({from:`"${t.siteName||"Low Flame"}" <${n}>`,to:e.to,replyTo:i,subject:e.subject,text:e.text||e.html.replace(/<[^>]*>/g,""),html:e.html}),{success:!0}}catch(e){return console.error("[Email] Send failed:",e),{success:!1,error:e.message}}}function s(e){return{subject:"Welcome to Low Flame!",html:`
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:30px 20px">
        <div style="text-align:center;margin-bottom:30px">
          <span style="font-size:36px">🏮</span>
          <h1 style="font-size:24px;color:#1a1a2e;margin:10px 0 5px">Welcome, ${i(e)}!</h1>
          <p style="color:#666;font-size:14px">Thank you for joining Low Flame</p>
        </div>
        <div style="background:#f9f5f0;border-radius:8px;padding:25px;margin-bottom:25px">
          <p style="color:#333;font-size:14px;line-height:1.6">Discover authentic Chinese craftsmanship — hand-selected ceramics, silk embroidery, bamboo weaving, and more, shipped directly to your door.</p>
          <div style="text-align:center;margin:25px 0">
            <a href="${process.env.NEXT_PUBLIC_SITE_URL||"http://localhost:3001"}/#products"
               style="display:inline-block;padding:12px 30px;background:#A83420;color:#fff;text-decoration:none;border-radius:4px;font-size:14px">
              Start Shopping
            </a>
          </div>
        </div>
        <p style="color:#999;font-size:11px;text-align:center">Low Flame &middot; Bringing the artistry of China to the world</p>
      </div>
    `.trim()}}function l(e,t,r,o){return{subject:"Order Confirmed - #"+t,html:`
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:30px 20px">
        <div style="text-align:center;margin-bottom:30px">
          <span style="font-size:48px">✅</span>
          <h1 style="font-size:24px;color:#1a1a2e;margin:10px 0 5px">Order Confirmed!</h1>
          <p style="color:#666;font-size:14px">Thank you, ${i(e)}!</p>
        </div>
        <div style="background:#f0f9f0;border-radius:8px;padding:25px;margin-bottom:25px">
          <p style="margin:0 0 15px;color:#333"><strong>Order #${i(t)}</strong></p>
          <p style="margin:0 0 5px;color:#666;font-size:14px">Items: ${o}</p>
          <p style="margin:0 0 5px;color:#666;font-size:14px">Total: $${r.toFixed(2)}</p>
          <p style="margin:0;color:#666;font-size:14px">Status: <strong style="color:#A83420">Processing</strong></p>
          <div style="text-align:center;margin:25px 0">
            <a href="${process.env.NEXT_PUBLIC_SITE_URL||"http://localhost:3001"}/account/orders"
               style="display:inline-block;padding:12px 30px;background:#A83420;color:#fff;text-decoration:none;border-radius:4px;font-size:14px">
              View Order
            </a>
          </div>
        </div>
        <p style="color:#999;font-size:11px;text-align:center">Low Flame &middot; We'll notify you when your order ships.</p>
      </div>
    `.trim()}}function c(e){let t=e.siteUrl||process.env.NEXT_PUBLIC_SITE_URL||"https://lowflame.store",r=e.customerName||"there",o="USD"!==e.currency&&e.currency?e.currency+" ":"$",n=(e.items||[]).slice(0,8).map(e=>`<li style="margin:0 0 6px;color:#555;font-size:14px">${i(e.name)}${e.quantity&&e.quantity>1?` &times; ${e.quantity}`:""}</li>`).join("");return{subject:`Your order #${e.orderNo} is waiting — complete your purchase`,html:`
      <div style="font-family:Georgia,'Times New Roman',serif;max-width:600px;margin:0 auto;padding:32px 24px;background:#FBFAF7">
        <div style="text-align:center;margin-bottom:28px">
          <h1 style="font-size:26px;color:#2A2118;margin:0 0 8px;font-weight:500">Your order is still waiting</h1>
          <p style="color:#5A4A36;font-size:14px;margin:0;font-family:Arial,sans-serif">
            Hello ${i(r)}, we saved your selection — but the payment didn&rsquo;t go through.
          </p>
        </div>

        <div style="background:#FFFFFF;border:1px solid #EFE7D4;border-radius:6px;padding:24px;margin-bottom:24px">
          <p style="margin:0 0 4px;color:#2A2118;font-size:15px;font-family:Arial,sans-serif">
            Order reference: <strong style="font-family:monospace">${i(e.orderNo)}</strong>
          </p>
          <p style="margin:0 0 16px;color:#5A4A36;font-size:14px;font-family:Arial,sans-serif">
            Total: <strong style="color:#2A2118">${o}${Number(e.total||0).toFixed(2)}</strong>
          </p>
          ${n?`<ul style="margin:0 0 20px;padding-left:20px;font-family:Arial,sans-serif">${n}</ul>`:""}
          <div style="text-align:center;margin:24px 0 8px">
            <a href="${t}/checkout"
               style="display:inline-block;padding:14px 36px;background:#4C5546;color:#FFFFFF;text-decoration:none;border-radius:4px;font-size:13px;letter-spacing:0.14em;text-transform:uppercase;font-family:Arial,sans-serif;font-weight:bold">
              Complete my order
            </a>
          </div>
          <p style="text-align:center;color:#8A7A62;font-size:12px;margin:14px 0 0;font-family:Arial,sans-serif">
            Or reply to this email if you need help with payment.
          </p>
        </div>

        <p style="color:#9A8C74;font-size:11px;text-align:center;font-family:Arial,sans-serif;line-height:1.7;margin:0">
          If you already completed this order, please ignore this message.<br />
          Low Flame &middot; Contemporary craftsmanship
        </p>
      </div>
    `.trim()}}function d(e){let t=e.siteUrl||process.env.NEXT_PUBLIC_SITE_URL||"https://lowflame.store",r=e.items||[],o=r.length?`
        <table style="width:100%;border-collapse:collapse;margin:15px 0">
          ${r.map(e=>`
            <tr>
              <td style="padding:6px 0;color:#333;font-size:13px">${i(e.name)}</td>
              <td style="padding:6px 0;color:#666;font-size:13px;text-align:right">\xd7&nbsp;${i(String(e.quantity||1))}</td>
            </tr>`).join("")}
        </table>`:"",n=e.trackingUrl?`<div style="text-align:center;margin:22px 0">
         <a href="${i(e.trackingUrl)}"
            style="display:inline-block;padding:12px 30px;background:#A83420;color:#fff;text-decoration:none;border-radius:4px;font-size:14px">
           Track Your Package
         </a>
       </div>`:"",a=e.estimatedDelivery?`<p style="margin:0 0 5px;color:#666;font-size:14px">Estimated delivery: <strong style="color:#333">${i(e.estimatedDelivery)}</strong></p>`:"";return{subject:"Your order #"+e.orderNo+" has shipped",html:`
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:30px 20px">
        <div style="text-align:center;margin-bottom:30px">
          <span style="font-size:48px">📦</span>
          <h1 style="font-size:24px;color:#1a1a2e;margin:10px 0 5px">Your order is on its way!</h1>
          <p style="color:#666;font-size:14px">${e.customerName?"Thank you, "+i(e.customerName)+"!":"Thank you for your order!"}</p>
        </div>
        <div style="background:#f9f5f0;border-radius:8px;padding:25px;margin-bottom:25px">
          <p style="margin:0 0 12px;color:#333"><strong>Order #${i(e.orderNo)}</strong></p>
          <p style="margin:0 0 5px;color:#666;font-size:14px">Carrier: <strong style="color:#333">${i(e.carrierName||"-")}</strong></p>
          <p style="margin:0 0 5px;color:#666;font-size:14px">Tracking number: <strong style="color:#333;font-family:monospace">${i(e.trackingNumber)}</strong></p>
          ${a}
          ${o}
          ${n}
          <div style="text-align:center;margin-top:10px">
            <a href="${i(t)}/account/orders"
               style="color:#A83420;font-size:13px;text-decoration:underline">View your order</a>
          </div>
        </div>
        <p style="color:#999;font-size:12px;line-height:1.6;text-align:center">
          If you have any questions, just reply to this email and we will get back to you.<br />
          Low Flame &middot; Bringing the artistry of China to the world
        </p>
      </div>
    `.trim()}}},80426:(e,t,r)=>{"use strict";r.d(t,{bw:()=>l,pR:()=>c});var o=r(20351),n=r(8861),i=r(10626),a=r(6347),s=r(32979);function l(e,t,r){let o=function(e,t,r){if(e.referralCode)return(0,a.I4)({referralCode:e.referralCode,visitorId:t,model:r.attributionModel,lookbackDays:r.attributionLookbackDays,requireVisitorMatch:r.attributionRequireVisitorMatch,allowReferralFallback:r.attributionAllowReferralFallback})}(e,t,r);if(o)return e.attributionClickId=o.click.id,e.attributionModel=o.model,e.attributionTouchpoints=o.totalTouchpointsCount||o.touchpoints?.length||1,e.attributionLookbackDays=o.lookbackDays,e.attributionMatchedBy=o.matchedBy,e.attributionFallbackUsed=o.fallbackUsed,o.touchpoints&&Array.isArray(o.touchpoints)?(0,a.EK)(o.touchpoints,e.id,e.total||0):(0,a.EK)([{click:o.click,weight:1}],e.id,e.total||0),o}function c(e,t={}){let r=(0,o.TM)(),a=r.settings.get();if(!1!==t.markReferralConversion&&e.referralCode)try{l(e,e.referralVisitorId,a),r.orders.update(e.id,{attributionClickId:e.attributionClickId,attributionModel:e.attributionModel,attributionTouchpoints:e.attributionTouchpoints,attributionLookbackDays:e.attributionLookbackDays,attributionMatchedBy:e.attributionMatchedBy,attributionFallbackUsed:e.attributionFallbackUsed})}catch(e){console.warn("[OrderFinalize] 归因转化失败:",e)}if(!1!==t.deductStock)try{let t=(0,n.d_)(e);if(t.shortfall.length>0){let o=`⚠ 库存不足: ${t.shortfall.join("; ")}`,n=r.orders.getById(e.id);r.orders.update(e.id,{notes:((n?.notes||e.notes||"")+"\n"+o).trim()}),console.warn(`[OrderFinalize] ${o} (order ${e.id})`)}}catch(e){console.warn("[OrderFinalize] 扣库存失败:",e)}if(!1!==t.consumeCoupon&&t.couponCode){try{(0,i.xm)(t.couponCode)}catch(e){console.warn("[OrderFinalize] 优惠券核销失败:",e)}if(t.welcomeCouponUserId&&t.welcomeCouponCode)try{let e=r.users.getById(t.welcomeCouponUserId);if(e){let o=(e.coupons||[]).map(e=>String(e.code).toLowerCase()===t.welcomeCouponCode.toLowerCase()?{...e,used:!0}:e);r.users.update(t.welcomeCouponUserId,{coupons:o})}}catch{console.warn("[OrderFinalize] welcome 券标记失败:",t.welcomeCouponCode)}}if(!1!==t.sendEmail&&e.customerEmail)try{let t=(0,s.CK)(e.customerName||"Customer",e.id,e.total,Array.isArray(e.items)?e.items.length:0);(0,s.ZM)({to:e.customerEmail,...t}).then(e=>{e?.success||console.warn("[OrderFinalize] 确认邮件未发送:",e?.error)})}catch(e){console.warn("[OrderFinalize] 确认邮件构造失败:",e)}}},10626:(e,t,r)=>{"use strict";r.d(t,{zb:()=>c,rS:()=>A,ou:()=>w,W_:()=>S,tD:()=>k,Nz:()=>v,DB:()=>I,s9:()=>x,x6:()=>C,xm:()=>T,c8:()=>F,PX:()=>b,ai:()=>d});var o=r(29021),n=r.n(o),i=r(33873),a=r.n(i);function s(e){return Math.round(100*e)/100}function l(e,t){return"percent"===e.discountType?t*e.value/100:e.value}function c(e,t,r=Date.now()){let o=t.filter(t=>t.active&&(!t.startAt||new Date(t.startAt).getTime()<=r)&&(!t.endAt||new Date(t.endAt).getTime()>=r)&&("all"===t.scope||"product"===t.scope&&t.targetId===e.id||"category"===t.scope&&t.targetId===e.category));if(0===o.length)return{price:e.price,discount:0};let n=e=>"product"===e.scope?0:"category"===e.scope?1:2,i=o.sort((t,r)=>n(t)-n(r)||l(r,e.price)-l(t,e.price))[0],a=l(i,e.price);return{price:s(Math.max(0,e.price-a)),originalPrice:e.price,discount:s(a),promoName:i.name}}function d(e,t,r=Date.now()){if(!e.active)return{ok:!1,discount:0,error:"Coupon is not active"};if(void 0!==e.maxUsage&&e.usedCount>=e.maxUsage)return{ok:!1,discount:0,error:"Coupon usage limit reached"};if(r>new Date(e.createdAt).getTime()+864e5*e.validDays)return{ok:!1,discount:0,error:"Coupon has expired"};if(t<e.minSpend)return{ok:!1,discount:0,error:`Minimum spend is $${e.minSpend.toFixed(2)}`};let o="percent"===e.discountType?t*e.value/100:e.value;return e.maxDiscount&&(o=Math.min(o,e.maxDiscount)),{ok:!0,discount:s(o=Math.min(o,t))}}let u=a().join(process.cwd(),"data"),p=a().join(u,"promotions.json"),f=a().join(u,"coupons.json");function m(e){n().existsSync(u)||n().mkdirSync(u,{recursive:!0}),n().existsSync(e)||n().writeFileSync(e,"[]","utf-8")}function g(e){m(e);try{let t=n().readFileSync(e,"utf-8").replace(/^\uFEFF/,""),r=JSON.parse(t);return Array.isArray(r)?r:[]}catch{return[]}}function y(e,t){m(e),n().writeFileSync(e,JSON.stringify(t,null,2),"utf-8")}function h(e){return e+"-"+Date.now().toString(36).toUpperCase()+"-"+Math.random().toString(36).slice(2,7).toUpperCase()}function x(){return g(p)}function v(e=Date.now()){return x().filter(t=>t.active&&(!t.startAt||new Date(t.startAt).getTime()<=e)&&(!t.endAt||new Date(t.endAt).getTime()>=e))}function w(e){let t=x(),r={...e,id:h("PROMO"),createdAt:new Date().toISOString()};return t.push(r),y(p,t),r}function b(e,t){let r=x(),o=r.findIndex(t=>t.id===e);return o<0?null:(r[o]={...r[o],...t},y(p,r),r[o])}function k(e){let t=x(),r=t.filter(t=>t.id!==e);return r.length!==t.length&&(y(p,r),!0)}function I(){return g(f)}function C(e){return I().find(t=>t.code.toLowerCase()===e.trim().toLowerCase())}function A(e){let t=I(),r={...e,code:e.code.trim().toUpperCase(),id:h("CPN"),usedCount:0,createdAt:new Date().toISOString()};return t.push(r),y(f,t),r}function F(e,t){let r=I(),o=r.findIndex(t=>t.id===e);return o<0?null:(r[o]={...r[o],...t},y(f,r),r[o])}function S(e){let t=I(),r=t.filter(t=>t.id!==e);return r.length!==t.length&&(y(f,r),!0)}function T(e){let t=C(e);t&&(void 0===t.maxUsage||t.usedCount<t.maxUsage)&&F(t.id,{usedCount:t.usedCount+1})}},6347:(e,t,r)=>{"use strict";r.d(t,{QL:()=>g,rY:()=>h,I4:()=>b,_d:()=>v,a_:()=>u,kz:()=>w,G5:()=>f,ke:()=>p,t0:()=>C,jv:()=>A,EK:()=>I,z_:()=>x,jN:()=>y});var o=r(29021),n=r.n(o),i=r(33873),a=r.n(i);let s=a().join(process.cwd(),"data"),l=a().join(s,"referrals.json"),c=a().join(s,"referral-clicks.json");function d(e){n().existsSync(s)||n().mkdirSync(s,{recursive:!0}),n().existsSync(e)||n().writeFileSync(e,"[]","utf-8")}function u(){d(l);let e=n().readFileSync(l,"utf-8").replace(/^\uFEFF/,"");try{let t=JSON.parse(e);return Array.isArray(t)?t.sort((e,t)=>new Date(t.createdAt).getTime()-new Date(e.createdAt).getTime()):[]}catch{return[]}}function p(e){return u().find(t=>t.id===e)}function f(e){return u().find(t=>t.code===e&&"active"===t.status)}function m(e){return u().filter(t=>t.staffId===e)}function g(e){d(l);let t=u(),r=function e(){let t="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",r="";for(let e=0;e<8;e++)r+=t.charAt(Math.floor(Math.random()*t.length));return u().find(e=>e.code===r)?e():r}(),o={id:`ref_${Date.now()}_${Math.random().toString(36).slice(2,8)}`,staffId:e.staffId,staffName:e.staffName,staffAvatar:e.staffAvatar,platform:e.platform,platformUsername:e.platformUsername,productId:e.productId,productName:e.productName,url:function({code:e,productId:t,fallbackUrl:r,sourceChannel:o}){if(!e)return"";let n=new URL("/link-in-bio",function(e){if(e)try{return new URL(e).origin}catch{}let t=process.env.NEXT_PUBLIC_SITE_URL?.trim();if(t)try{return new URL(t).origin}catch{}return"http://localhost:3000"}(r));return n.searchParams.set("ref",e),t&&n.searchParams.set("product",t),o&&n.searchParams.set("channel",o),n.toString()}({code:r,productId:e.productId}),code:r,createdAt:new Date().toISOString(),status:"active",clicks:0,conversions:0,revenue:0,contentTitle:e.contentTitle,contentBody:e.contentBody,hashtags:e.hashtags,contentType:e.contentType,tone:e.tone,publishedAt:e.publishedAt||new Date().toISOString(),preferredSourceChannel:e.preferredSourceChannel||"bio"};return t.unshift(o),n().writeFileSync(l,JSON.stringify(t,null,2),"utf-8"),o}function y(e,t){d(l);let r=u(),o=r.findIndex(t=>t.id===e);return o<0?null:(r[o]={...r[o],...t,id:r[o].id,createdAt:r[o].createdAt},n().writeFileSync(l,JSON.stringify(r,null,2),"utf-8"),r[o])}function h(e){d(l);let t=u(),r=t.filter(t=>t.id!==e);return r.length!==t.length&&(n().writeFileSync(l,JSON.stringify(r,null,2),"utf-8"),!0)}function x(e){d(c);let t=v(),r={id:`click_${Date.now()}_${Math.random().toString(36).slice(2,8)}`,referralId:e.referralId,referralCode:e.referralCode,staffId:e.staffId,platform:e.platform,visitorId:e.visitorId,ip:e.ip,userAgent:e.userAgent,page:e.page,query:e.query,sourceChannel:e.sourceChannel||"direct",createdAt:new Date().toISOString(),converted:!1};t.unshift(r),n().writeFileSync(c,JSON.stringify(t,null,2),"utf-8");let o=p(e.referralId);return o&&y(e.referralId,{clicks:o.clicks+1}),r}function v(){d(c);let e=n().readFileSync(c,"utf-8").replace(/^\uFEFF/,"");try{let t=JSON.parse(e);return Array.isArray(t)?t.sort((e,t)=>new Date(t.createdAt).getTime()-new Date(e.createdAt).getTime()):[]}catch{return[]}}function w(e){return v().find(t=>t.orderId===e)}function b(e){let t=e.lookbackDays||7,r=Date.now()-864e5*t,o=v().filter(e=>!e.converted&&new Date(e.createdAt).getTime()>=r).filter(t=>{let r=e.referralCode&&t.referralCode===e.referralCode,o=e.visitorId&&t.visitorId===e.visitorId;return e.requireVisitorMatch&&!e.allowReferralFallback?o:r||o});if(0===o.length)return;let n=e.model||"last_click";o.sort((e,t)=>new Date(t.createdAt).getTime()-new Date(e.createdAt).getTime());let i="referral_code",a=!1,s=o.some(t=>t.visitorId===e.visitorId);s?i="visitor":a=!!e.visitorId;let l=s?o.filter(t=>t.visitorId===e.visitorId):o,c=[],d=l[0];if("last_click"===n)c=[{click:d=l[0],weight:1}];else if("first_click"===n)c=[{click:d=l[l.length-1],weight:1}];else if("multi_touch"===n){let e=l.length;1===e?c=[{click:d=l[0],weight:1}]:2===e?(d=l[0],c=[{click:l[0],weight:.5},{click:l[1],weight:.5}]):(d=l[0],c=l.map((t,r)=>0===r||r===e-1?{click:t,weight:.4}:{click:t,weight:.2/(e-2)}))}return{click:d,touchpoints:c,model:n,lookbackDays:t,totalTouchpointsCount:l.length,matchedBy:i,fallbackUsed:a}}function k(e){return v().filter(t=>t.staffId===e)}function I(e,t,r){d(c);let o=v(),i=!1;for(let n of e){let e=o.findIndex(e=>e.id===n.click.id);if(e<0||o[e].converted)continue;o[e]={...o[e],converted:!0,orderId:t},i=!0;let a=p(o[e].referralId);a&&y(o[e].referralId,{conversions:a.conversions+n.weight,revenue:a.revenue+r*n.weight})}return i&&n().writeFileSync(c,JSON.stringify(o,null,2),"utf-8"),i}function C(e){let t=e?m(e):u(),r=e?k(e):v(),o=t.length,n=r.length,i=r.filter(e=>e.converted).length,a=t.reduce((e,t)=>e+t.revenue,0),s={},l={},c={},d={},f={},g={};r.forEach(e=>{s[e.platform]=(s[e.platform]||0)+1;let t=e.sourceChannel||"direct";l[t]=(l[t]||0)+1,e.converted&&(d[e.platform]=(d[e.platform]||0)+1,c[t]=(c[t]||0)+1);let r=g[e.staffId];if(r)r.clicks++,e.converted&&r.conversions++;else{let t=p(e.referralId);g[e.staffId]={clicks:1,conversions:e.converted?1:0,revenue:0,name:t?.staffName||"Unknown",avatar:t?.staffAvatar}}}),t.forEach(e=>{f[e.platform]=(f[e.platform]||0)+e.revenue;let t=g[e.staffId];t&&(t.revenue+=e.revenue)});let y=[...t].sort((e,t)=>t.clicks-e.clicks);return{totalLinks:o,totalClicks:n,totalConversions:i,totalRevenue:a,conversionRate:Math.round(100*(n>0?i/n*100:0))/100,clicksByPlatform:s,clicksByChannel:l,conversionsByChannel:c,conversionsByPlatform:d,revenueByPlatform:f,clicksByStaff:g,recentClicks:r.slice(0,20),allClicks:r,topLinks:y.slice(0,10),allLinks:t}}function A(e){let t=m(e),r=k(e),o=t.length,n=r.length,i=r.filter(e=>e.converted).length,a=t.reduce((e,t)=>e+t.revenue,0),s={},l={};return r.forEach(e=>{s[e.platform]=(s[e.platform]||0)+1;let t=e.sourceChannel||"direct";l[t]=(l[t]||0)+1}),{totalLinks:o,totalClicks:n,totalConversions:i,totalRevenue:a,conversionRate:Math.round(100*(n>0?i/n*100:0))/100,clicksByPlatform:s,clicksByChannel:l,topLinks:[...t].sort((e,t)=>t.clicks-e.clicks).slice(0,5)}}},8861:(e,t,r)=>{"use strict";r.d(t,{Ef:()=>i,d_:()=>n});var o=r(20351);function n(e){let t=(0,o.TM)(),r=[],n=0;for(let o of e?.items||[]){let e=o.productId||o.id;if(!e)continue;let i=t.products.getById(e);if(!i)continue;let a=Number(o.quantity)||1,s=Number(i.stock)||0;if(s<a){r.push(`${o.name||e} (need ${a}, have ${s})`);continue}t.products.update(e,{stock:s-a}),n+=a}return{deducted:n,shortfall:r}}function i(e){let t=(0,o.TM)(),r=0;for(let o of e?.items||[]){let e=o.productId||o.id;if(!e)continue;let n=t.products.getById(e);if(!n)continue;let i=Number(o.quantity)||1,a=Number(n.stock)||0;t.products.update(e,{stock:a+i}),r+=i}return{deducted:r,shortfall:[]}}}};