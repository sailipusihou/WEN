"use strict";exports.id=8818,exports.ids=[8818],exports.modules={51105:(e,t,r)=>{r.d(t,{U_:()=>i,gm:()=>o,hi:()=>s});let a=new Map,i={products:1e4,categories:3e4,settings:6e4,orders:2e3,users:1e4,reviews:3e4,messages:2e3};function s(e,t,i,o=5e3){let n=r(29021),d=Date.now(),l=a.get(e);try{let r=n.statSync(t).mtimeMs;if(l&&l.mtime===r&&d-l.timestamp<o)return l.data;let s=i();return a.set(e,{data:s,timestamp:d,mtime:r}),s}catch{if(l)return l.data;return i()}}function o(e){a.delete(e)}},63783:(e,t,r)=>{r.r(t),r.d(t,{addCategory:()=>m,deleteCategory:()=>g,getAllCategories:()=>c,getCategoryBySlug:()=>E,updateCategory:()=>T});var a=r(29021),i=r.n(a),s=r(33873),o=r.n(s),n=r(62545),d=r(51105);let l=o().join(process.cwd(),"data"),u=o().join(l,"categories.json");function p(){try{let e=i().readFileSync(u,"utf-8").replace(/^\uFEFF/,"");return JSON.parse(e)}catch{return[]}}function c(){try{let e=(0,d.hi)("categories",u,p,d.U_.categories),t=[];try{t=(0,n.getAllProducts)()}catch(e){console.error("Error getting products:",e)}return e.map(e=>({...e,productCount:t.filter(t=>t.category===e.slug).length}))}catch(e){return console.error("Error getting categories:",e),[]}}function E(e){return c().find(t=>t.slug===e)}function m(e,t){let r=p();if(r.some(t=>t.slug===e))throw Error("Category slug already exists");let a={slug:e,name:t.name||e,nameEn:t.nameEn||"",description:t.description||"",descriptionEn:t.descriptionEn||"",icon:t.icon||"\uD83D\uDCE6",productCount:0,image:t.image||""};return r.push(a),i().writeFileSync(u,JSON.stringify(r,null,2),"utf-8"),(0,d.gm)("categories"),c()}function T(e,t){let r=p(),a=r.findIndex(t=>t.slug===e);if(-1===a)throw Error("Not found");return r[a]={...r[a],...t,slug:e},i().writeFileSync(u,JSON.stringify(r,null,2),"utf-8"),(0,d.gm)("categories"),c()}function g(e){let t=p().filter(t=>t.slug!==e);return i().writeFileSync(u,JSON.stringify(t,null,2),"utf-8"),(0,d.gm)("categories"),c()}},62545:(e,t,r)=>{r.r(t),r.d(t,{addProduct:()=>I,addReview:()=>v,deleteProduct:()=>A,generateProductCode:()=>c,getActiveProducts:()=>T,getAllProducts:()=>m,getAllReviews:()=>N,getFeaturedProducts:()=>h,getProductById:()=>g,getProductsByCategory:()=>f,getReviewsByProduct:()=>b,isValidProductCode:()=>E,saveAllProducts:()=>y,updateProduct:()=>S,updateReview:()=>L});var a=r(29021),i=r.n(a),s=r(33873),o=r.n(s),n=r(51105);let d=o().join(process.cwd(),"data"),l=o().join(d,"products.json"),u=o().join(d,"reviews.json"),p={"cultural-gifts":"CG","home-decor":"HD","creative-gifts":"GI"};function c(e,t){let r=p[e]||"GEN",a=0,i=RegExp(`^${r}-(\\d+)$`);for(let e of t){if(!e)continue;let t=e.match(i);t&&(a=Math.max(a,parseInt(t[1],10)))}let s=a+1;for(;t.has(`${r}-${String(s).padStart(4,"0")}`);)s++;return`${r}-${String(s).padStart(4,"0")}`}function E(e){return/^[A-Z]{2,4}-\d{3,6}$/.test(e)}function m(){return R(l),(0,n.hi)("products",l,()=>JSON.parse(i().readFileSync(l,"utf-8").replace(/^\uFEFF/,"")),n.U_.products)}function T(){return m().filter(e=>e.active)}function g(e){return m().find(t=>t.id===e)}function f(e){return T().filter(t=>t.category===e)}function h(){return T().filter(e=>e.featured)}function y(e){i().writeFileSync(l,JSON.stringify(e,null,2),"utf-8"),(0,n.gm)("products")}function I(e){let t=m();return t.push(e),y(t),e}function S(e,t){let r=m(),a=r.findIndex(t=>t.id===e);return -1===a?null:(r[a]={...r[a],...t},y(r),r[a])}function A(e){let t=m(),r=t.findIndex(t=>t.id===e);return -1!==r&&(t.splice(r,1),y(t),!0)}function N(){return R(u),(0,n.hi)("reviews",u,()=>JSON.parse(i().readFileSync(u,"utf-8").replace(/^\uFEFF/,"")),n.U_.reviews)}function b(e){return N().filter(t=>t.productId===e)}function v(e){let t=N(),r={id:"REV-"+Date.now().toString(36).toUpperCase(),productId:e.productId,author:e.author||"Anonymous",avatar:(e.author||"A")[0].toUpperCase(),rating:e.rating,date:new Date().toLocaleDateString("en-US",{year:"numeric",month:"long",day:"numeric"}),content:e.content||"",location:e.location||"Verified Buyer",approved:void 0!==e.approved&&e.approved,createdAt:new Date().toISOString()};return t.unshift(r),i().writeFileSync(u,JSON.stringify(t,null,2),"utf-8"),(0,n.gm)("reviews"),r}function L(e,t){let r=N(),a=r.findIndex(t=>t.id===e);return -1===a?null:(r[a]={...r[a],...t},i().writeFileSync(u,JSON.stringify(r,null,2),"utf-8"),(0,n.gm)("reviews"),r[a])}function R(e){i().existsSync(d)||i().mkdirSync(d,{recursive:!0}),i().existsSync(e)||i().writeFileSync(e,"[]","utf-8")}},2885:(e,t,r)=>{r.r(t),r.d(t,{attachBundlesToProducts:()=>n,attachGiftsToProducts:()=>o,attachVariantsToProducts:()=>l,browsingHistoryRepo:()=>U,categoryRepo:()=>y,customerRepo:()=>X,messageRepo:()=>L,newsletterRepo:()=>D,orderRepo:()=>I,productRepo:()=>f,reviewRepo:()=>A,settingsRepo:()=>O,shipmentRepo:()=>k,staffRepo:()=>C,supplierRepo:()=>h,userRepo:()=>S,workLogRepo:()=>w});var a=r(18084),i=r(68818);function s(e){return{id:e.id,code:e.code||void 0,name:e.name,nameEn:e.nameEn||"",subtitle:e.subtitle||"",subtitleEn:e.subtitleEn||"",description:e.description||"",descriptionEn:e.descriptionEn||"",story:e.story||"",storyEn:e.storyEn||"",price:e.price,originalPrice:e.originalPrice||void 0,costPrice:e.costPrice||void 0,stock:e.stock||0,supplierId:e.supplierId||void 0,category:e.category||"",image:e.image||"",video:e.video||void 0,videoEnabled:!!e.videoEnabled,craft:e.craft||"",craftEn:e.craftEn||"",material:e.material||"",origin:e.origin||"",rating:e.rating||0,reviewCount:e.reviewCount||0,featured:!!e.featured,active:0!==e.active,listingVisible:void 0===e.listingVisible||null===e.listingVisible||0!==e.listingVisible,tags:[],tagsEn:[],detailImages:[],giftProductIds:[],giftQuantity:1}}function o(e,t){if(!t.length)return t;try{let r=e.prepare("SELECT productId, giftProductId, quantity, sortOrder FROM product_gifts ORDER BY productId, sortOrder").all();if(!r.length)return t;let a=new Map;for(let e of r){let t=a.get(e.productId)||{ids:[],qty:1};t.ids.push(e.giftProductId),t.qty=Math.max(1,Number(e.quantity)||1),a.set(e.productId,t)}for(let e of t){let t=a.get(e.id);t&&(e.giftProductIds=t.ids,e.giftQuantity=t.qty)}}catch{}return t}function n(e,t){if(!t.length)return t;try{let r=e.prepare("SELECT * FROM product_bundles ORDER BY productId, sortOrder").all();if(!r.length)return t;let a=new Map;for(let e of t)a.set(e.id,e);let i=t=>{if(a.has(t))return a.get(t);try{let r=e.prepare("SELECT * FROM products WHERE id = ?").get(t);if(!r)return null;let i=s(r);return p(i),a.set(t,i),i}catch{return null}},o=new Map;for(let e of r)o.has(e.productId)||o.set(e.productId,[]),o.get(e.productId).push({bundleProductId:e.bundleProductId,title:e.title||"",description:e.description||"",image:e.image||void 0,price:null===e.price||void 0===e.price?void 0:Number(e.price),discount:Number(e.discount)||0,sortOrder:Number(e.sortOrder)||0});for(let e of t){let t=o.get(e.id);t&&t.length&&(e.bundles=t.map(e=>({...e,product:i(e.bundleProductId)})))}}catch{}return t}function d(e){return{id:e.id,productId:e.productId,optionName:e.optionName||"",label:e.label,valueCode:e.valueCode||"",price:null===e.price||void 0===e.price?void 0:Number(e.price),image:e.image||void 0,stock:null===e.stock||void 0===e.stock?void 0:Number(e.stock),sortOrder:Number(e.sortOrder)||0,active:0!==e.active}}function l(e,t){if(!t.length)return t;try{let r=e.prepare("SELECT * FROM product_variants WHERE active = 1 ORDER BY productId, sortOrder").all();if(!r.length)return t;let a=new Map;for(let e of r)a.has(e.productId)||a.set(e.productId,[]),a.get(e.productId).push(d(e));for(let e of t){let t=a.get(e.id);t&&t.length&&(e.variants=t,e.optionName=t[0].optionName||"Style")}}catch{}return t}function u(e){return{id:e.id,name:e.name,contact:e.contact||void 0,phone:e.phone||void 0,email:e.email||void 0,address:e.address||void 0,region:e.region||void 0,status:e.status||"active",notes:e.notes||void 0,createdAt:e.createdAt,updatedAt:e.updatedAt}}function p(e){let t=(0,a.Lf)();if(e.supplierId){let r=t.prepare("SELECT * FROM suppliers WHERE id = ?").get(e.supplierId);r&&(e.supplier=u(r))}let r=t.prepare("SELECT tag, lang FROM product_tags WHERE productId = ? ORDER BY sortOrder").all(e.id);e.tags=r.filter(e=>"zh"===e.lang).map(e=>e.tag),e.tagsEn=r.filter(e=>"en"===e.lang).map(e=>e.tag);let i=t.prepare("SELECT imageUrl FROM product_images WHERE productId = ? ORDER BY sortOrder").all(e.id);e.detailImages=i.map(e=>e.imageUrl)}function c(e,t=0){return{slug:e.slug,name:e.name,nameEn:e.nameEn||"",description:e.description||"",descriptionEn:e.descriptionEn||"",icon:e.icon||"棣冩憹",productCount:t,image:e.image||""}}function E(e,t){var r;let i=(r=e.id,(0,a.Lf)().prepare("SELECT status, note, timestamp FROM order_status_history WHERE orderId = ? ORDER BY timestamp ASC").all(r).map(e=>({status:e.status,timestamp:e.timestamp,note:e.note||void 0})));return{id:e.id,items:t,shipping:{firstName:e.shippingName?.split(" ")[0]||"",lastName:e.shippingName?.split(" ").slice(1).join(" ")||"",email:e.customerEmail||"",phone:e.customerPhone||"",address:e.shippingAddress||"",city:e.shippingCity||"",state:e.shippingState||"",zipCode:e.shippingZip||"",country:e.shippingCountry||"United States"},subtotal:e.subtotal||0,discount:e.discount||0,couponCode:e.couponCode||void 0,shippingCost:e.shipping||0,total:e.totalAmount||0,currency:e.currency||"USD",status:e.status||"pending",createdAt:e.createdAt,notes:e.notes||void 0,paymentMethod:e.paymentMethod||void 0,customerEmail:e.customerEmail,customerName:e.customerName,userEmail:e.userEmail,referralCode:e.referralCode||void 0,referralId:e.referralId||void 0,referralVisitorId:e.referralVisitorId||void 0,referredByStaffId:e.referredByStaffId||void 0,referredByStaffName:e.referredByStaffName||void 0,attributionClickId:e.attributionClickId||void 0,attributionModel:e.attributionModel||void 0,attributionTouchpoints:e.attributionTouchpoints||void 0,attributionLookbackDays:e.attributionLookbackDays||void 0,attributionMatchedBy:e.attributionMatchedBy||void 0,attributionFallbackUsed:!!e.attributionFallbackUsed,assignedTo:e.assignedTo,assignedToName:e.assignedToName,assignedToAvatar:e.assignedToAvatar,estimatedDeliveryDays:e.estimatedDeliveryDays||void 0,tracking:e.trackingNumber?{carrier:e.carrier||"",trackingNumber:e.trackingNumber,estimatedDelivery:e.estimatedDelivery||"",url:e.trackingUrl||""}:void 0,statusHistory:i.length>0?i:void 0,paymentStatus:e.paymentStatus||void 0,paypalTransaction:e.paypalTransaction?m(e.paypalTransaction):void 0,payoneerTransaction:e.payoneerTransaction?m(e.payoneerTransaction):void 0,returnInfo:e.returnInfo?m(e.returnInfo):void 0}}function m(e){try{return JSON.parse(e)}catch{return}}function T(e,t,r){let a;if(e.coupons)try{a=JSON.parse(e.coupons)}catch{}return{id:e.id,email:e.email,passwordHash:e.passwordHash,salt:e.salt,firstName:e.firstName||"",lastName:e.lastName||"",phone:e.phone||"",avatar:e.avatar||void 0,dob:e.dob||void 0,gender:e.gender||void 0,bio:e.bio||void 0,preferredCurrency:e.preferredCurrency||"USD",coupons:a,wishlist:r,addresses:t,token:e.token||void 0,createdAt:e.createdAt,updatedAt:e.updatedAt||e.createdAt}}function g(e){return{id:e.id,productId:e.productId,author:e.author||"Anonymous",avatar:e.avatar||(e.author||"A")[0].toUpperCase(),rating:e.rating,date:e.date||new Date(e.createdAt).toLocaleDateString("en-US",{year:"numeric",month:"long",day:"numeric"}),content:e.content||"",location:e.location||"Verified Buyer",approved:!!e.approved,orderId:e.orderId||void 0,customerEmail:e.customerEmail||void 0,source:e.source||"customer",hidden:!!e.hidden,deleted:!!e.deleted,createdAt:e.createdAt}}let f={list(){let e=(0,a.Lf)(),t=e.prepare("SELECT * FROM products ORDER BY sortOrder DESC, createdAt DESC").all().map(s);return t.forEach(p),n(e,l(e,o(e,t)))},listActive(){let e=(0,a.Lf)(),t=e.prepare("SELECT * FROM products WHERE active = 1 AND (listingVisible IS NULL OR listingVisible != 0) ORDER BY sortOrder DESC, createdAt DESC").all().map(s);return t.forEach(p),n(e,l(e,o(e,t)))},getById(e){let t=(0,a.Lf)(),r=t.prepare("SELECT * FROM products WHERE id = ?").get(e);if(!r)return;let i=s(r);return p(i),n(t,l(t,o(t,[i]))),i},getByCategory(e){let t=(0,a.Lf)(),r=t.prepare("SELECT * FROM products WHERE category = ? AND active = 1 AND (listingVisible IS NULL OR listingVisible != 0) ORDER BY sortOrder DESC, createdAt DESC").all(e).map(s);return r.forEach(p),n(t,l(t,o(t,r)))},listGifts(e){let t=(0,a.Lf)();try{let r=t.prepare("SELECT p.* FROM product_gifts g JOIN products p ON p.id = g.giftProductId WHERE g.productId = ? ORDER BY g.sortOrder").all(e).map(s);return r.forEach(p),r}catch{return[]}},setGifts(e,t,r=1){let i=(0,a.Lf)();i.transaction(()=>{i.prepare("DELETE FROM product_gifts WHERE productId = ?").run(e);let a=i.prepare("INSERT OR REPLACE INTO product_gifts (productId, giftProductId, quantity, sortOrder) VALUES (?, ?, ?, ?)"),s=Math.max(1,Number(r)||1),o=new Set,n=0;for(let r of t)!r||r===e||o.has(r)||(o.add(r),a.run(e,r,s,n++))})()},allGiftBindings(){let e=(0,a.Lf)();try{let t=e.prepare("SELECT productId, giftProductId FROM product_gifts ORDER BY productId, sortOrder").all(),r={};for(let e of t)r[e.productId]||(r[e.productId]=[]),r[e.productId].push(e.giftProductId);return r}catch{return{}}},listVariants(e){let t=(0,a.Lf)();try{return t.prepare("SELECT * FROM product_variants WHERE productId = ? ORDER BY sortOrder, rowid").all(e).map(d)}catch{return[]}},setVariants(e,t){let r=(0,a.Lf)();r.transaction(()=>{r.prepare("DELETE FROM product_variants WHERE productId = ?").run(e);let a=r.prepare(`
        INSERT INTO product_variants
          (id, productId, optionName, label, valueCode, price, image, stock, sortOrder, active)
        VALUES (@id, @productId, @optionName, @label, @valueCode, @price, @image, @stock, @sortOrder, @active)
      `),i=new Set,s=0;for(let r of t||[]){let t=String(r?.label||"").trim();if(!t||i.has(t))continue;i.add(t);let o=e=>""===e||null==e||Number.isNaN(Number(e))?null:Number(e);a.run({id:String(r?.id||`${e}-var-${Date.now().toString(36)}-${s}`),productId:e,optionName:String(r?.optionName||"").trim(),label:t,valueCode:String(r?.valueCode||"").trim(),price:o(r?.price),image:r?.image?String(r.image):null,stock:o(r?.stock),sortOrder:s,active:r?.active===!1?0:1}),s++}})()},allVariants(){let e=(0,a.Lf)();try{let t=e.prepare("SELECT * FROM product_variants ORDER BY productId, sortOrder").all(),r={};for(let e of t)r[e.productId]||(r[e.productId]=[]),r[e.productId].push(d(e));return r}catch{return{}}},listBundles(e){let t=(0,a.Lf)();try{return t.prepare("SELECT * FROM product_bundles WHERE productId = ? ORDER BY sortOrder").all(e).map(e=>{let r=t.prepare("SELECT * FROM products WHERE id = ?").get(e.bundleProductId);return{bundleProductId:e.bundleProductId,title:e.title||"",description:e.description||"",image:e.image||void 0,price:null===e.price||void 0===e.price?void 0:Number(e.price),discount:Number(e.discount)||0,sortOrder:Number(e.sortOrder)||0,product:r?s(r):null}})}catch{return[]}},setBundles(e,t){let r=(0,a.Lf)();r.transaction(()=>{r.prepare("DELETE FROM product_bundles WHERE productId = ?").run(e);let a=r.prepare(`
        INSERT INTO product_bundles
          (productId, bundleProductId, title, description, image, price, discount, sortOrder)
        VALUES (@productId, @bundleProductId, @title, @description, @image, @price, @discount, @sortOrder)
      `),i=new Set,s=0;for(let r of t||[]){let t=String(r?.bundleProductId||"").trim();if(!t||t===e||i.has(t))continue;i.add(t);let o=e=>""===e||null==e||Number.isNaN(Number(e))?null:Number(e);a.run({productId:e,bundleProductId:t,title:String(r?.title||"").trim(),description:String(r?.description||"").trim(),image:r?.image?String(r.image):null,price:o(r?.price),discount:Math.max(0,Number(r?.discount)||0),sortOrder:s}),s++}})()},allBundles(){let e=(0,a.Lf)();try{let t=e.prepare("SELECT * FROM product_bundles ORDER BY productId, sortOrder").all(),r={};for(let e of t)r[e.productId]||(r[e.productId]=[]),r[e.productId].push({bundleProductId:e.bundleProductId,title:e.title||"",description:e.description||"",image:e.image||void 0,price:null===e.price||void 0===e.price?void 0:Number(e.price),discount:Number(e.discount)||0});return r}catch{return{}}},add(e){let t=(0,a.Lf)();if(t.prepare(`
      INSERT INTO products (id, code, name, nameEn, subtitle, subtitleEn, description, descriptionEn, story, storyEn,
        price, originalPrice, costPrice, stock, supplierId, category, image, video, videoEnabled, craft, craftEn, material, origin, rating, reviewCount, featured, active, listingVisible, sortOrder)
      VALUES (@id, @code, @name, @nameEn, @subtitle, @subtitleEn, @description, @descriptionEn, @story, @storyEn,
        @price, @originalPrice, @costPrice, @stock, @supplierId, @category, @image, @video, @videoEnabled, @craft, @craftEn, @material, @origin, @rating, @reviewCount, @featured, @active, @listingVisible, @sortOrder)
    `).run({id:e.id,code:e.code||null,name:e.name,nameEn:e.nameEn||"",subtitle:e.subtitle||"",subtitleEn:e.subtitleEn||"",description:e.description||"",descriptionEn:e.descriptionEn||"",story:e.story||"",storyEn:e.storyEn||"",price:e.price,originalPrice:e.originalPrice||null,costPrice:e.costPrice||null,stock:e.stock||0,supplierId:e.supplierId||null,category:e.category||"",image:e.image||"",video:e.video||null,videoEnabled:e.videoEnabled?1:0,craft:e.craft||"",craftEn:e.craftEn||"",material:e.material||"",origin:e.origin||"",rating:e.rating||0,reviewCount:e.reviewCount||0,featured:e.featured?1:0,active:!1!==e.active?1:0,listingVisible:!1===e.listingVisible?0:1,sortOrder:0}),e.tags?.length){let r=t.prepare("INSERT OR REPLACE INTO product_tags (productId, tag, lang, sortOrder) VALUES (?, ?, 'zh', ?)");e.tags.forEach((t,a)=>r.run(e.id,t,a))}if(e.tagsEn?.length){let r=t.prepare("INSERT OR REPLACE INTO product_tags (productId, tag, lang, sortOrder) VALUES (?, ?, 'en', ?)");e.tagsEn.forEach((t,a)=>r.run(e.id,t,a))}if(e.detailImages?.length){let r=t.prepare("INSERT OR REPLACE INTO product_images (productId, imageUrl, sortOrder) VALUES (?, ?, ?)");e.detailImages.forEach((t,a)=>r.run(e.id,t,a))}return e},update(e,t){let r=(0,a.Lf)(),i=f.getById(e);if(!i)return null;let s={...i,...t};if(r.prepare(`
      UPDATE products SET
        code = @code,
        name = @name, nameEn = @nameEn, subtitle = @subtitle, subtitleEn = @subtitleEn,
        description = @description, descriptionEn = @descriptionEn, story = @story, storyEn = @storyEn,
        price = @price, originalPrice = @originalPrice, costPrice = @costPrice, stock = @stock, supplierId = @supplierId,
        category = @category, image = @image,
        video = @video, videoEnabled = @videoEnabled,
        craft = @craft, craftEn = @craftEn, material = @material, origin = @origin,
        rating = @rating, reviewCount = @reviewCount, featured = @featured, active = @active,
        listingVisible = @listingVisible,
        updatedAt = datetime('now')
      WHERE id = @id
    `).run({id:e,code:s.code||null,name:s.name,nameEn:s.nameEn||"",subtitle:s.subtitle||"",subtitleEn:s.subtitleEn||"",description:s.description||"",descriptionEn:s.descriptionEn||"",story:s.story||"",storyEn:s.storyEn||"",price:s.price,originalPrice:s.originalPrice||null,costPrice:s.costPrice||null,stock:s.stock||0,supplierId:s.supplierId||null,category:s.category||"",image:s.image||"",video:s.video||null,videoEnabled:s.videoEnabled?1:0,craft:s.craft||"",craftEn:s.craftEn||"",material:s.material||"",origin:s.origin||"",rating:s.rating||0,reviewCount:s.reviewCount||0,featured:s.featured?1:0,active:!1!==s.active?1:0,listingVisible:!1===s.listingVisible?0:1}),t.tags){r.prepare("DELETE FROM product_tags WHERE productId = ? AND lang = 'zh'").run(e);let a=r.prepare("INSERT INTO product_tags (productId, tag, lang, sortOrder) VALUES (?, ?, 'zh', ?)");t.tags.forEach((t,r)=>a.run(e,t,r))}if(t.tagsEn){r.prepare("DELETE FROM product_tags WHERE productId = ? AND lang = 'en'").run(e);let a=r.prepare("INSERT INTO product_tags (productId, tag, lang, sortOrder) VALUES (?, ?, 'en', ?)");t.tagsEn.forEach((t,r)=>a.run(e,t,r))}if(t.detailImages){r.prepare("DELETE FROM product_images WHERE productId = ?").run(e);let a=r.prepare("INSERT INTO product_images (productId, imageUrl, sortOrder) VALUES (?, ?, ?)");t.detailImages.forEach((t,r)=>a.run(e,t,r))}return f.getById(e)||null},delete:e=>(0,a.Lf)().prepare("DELETE FROM products WHERE id = ?").run(e).changes>0},h={list:()=>(0,a.Lf)().prepare("SELECT * FROM suppliers ORDER BY name").all().map(u),getById(e){let t=(0,a.Lf)().prepare("SELECT * FROM suppliers WHERE id = ?").get(e);if(t)return u(t)},add(e){let t=(0,a.Lf)(),r=e.id||"SUP-"+Date.now().toString(36).toUpperCase(),i=new Date().toISOString(),s={id:r,name:e.name,contact:e.contact,phone:e.phone,email:e.email,address:e.address,region:e.region,status:e.status||"active",notes:e.notes,createdAt:i,updatedAt:i};return t.prepare(`
      INSERT INTO suppliers (id, name, contact, phone, email, address, region, status, notes, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(r,s.name,s.contact||"",s.phone||"",s.email||"",s.address||"",s.region||"",s.status,s.notes||"",i,i),s},update(e,t){let r=(0,a.Lf)();if(!h.getById(e))return null;let i=[],s=[];return void 0!==t.name&&(i.push("name = ?"),s.push(t.name)),void 0!==t.contact&&(i.push("contact = ?"),s.push(t.contact)),void 0!==t.phone&&(i.push("phone = ?"),s.push(t.phone)),void 0!==t.email&&(i.push("email = ?"),s.push(t.email)),void 0!==t.address&&(i.push("address = ?"),s.push(t.address)),void 0!==t.region&&(i.push("region = ?"),s.push(t.region)),void 0!==t.status&&(i.push("status = ?"),s.push(t.status)),void 0!==t.notes&&(i.push("notes = ?"),s.push(t.notes)),i.push("updatedAt = ?"),s.push(new Date().toISOString()),i.length>0&&(s.push(e),r.prepare(`UPDATE suppliers SET ${i.join(", ")} WHERE id = ?`).run(...s)),h.getById(e)||null},delete:e=>(0,a.Lf)().prepare("DELETE FROM suppliers WHERE id = ?").run(e).changes>0,getProductCount(e){let t=(0,a.Lf)().prepare("SELECT COUNT(*) as cnt FROM products WHERE supplierId = ?").get(e);return t?.cnt||0}},y={list(){let e=(0,a.Lf)();return e.prepare("SELECT * FROM categories ORDER BY sortOrder, name").all().map(t=>{let r=e.prepare("SELECT COUNT(*) as cnt FROM products WHERE category = ?").get(t.slug);return c(t,r.cnt)})},getBySlug(e){let t=(0,a.Lf)(),r=t.prepare("SELECT * FROM categories WHERE slug = ?").get(e);if(r)return c(r,t.prepare("SELECT COUNT(*) as cnt FROM products WHERE category = ? AND active = 1").get(e).cnt)},add(e){let t=(0,a.Lf)(),r=e.id||"CAT-"+e.slug;return t.prepare(`
      INSERT INTO categories (id, name, nameEn, slug, description, descriptionEn, image, icon, sortOrder, active)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 1)
    `).run(r,e.name,e.nameEn||"",e.slug,e.description||"",e.descriptionEn||"",e.image||"",e.icon||"棣冩憹"),e},update(e,t){let r=(0,a.Lf)(),i=y.getBySlug(e);if(!i)return null;let s={...i,...t};return r.prepare(`
      UPDATE categories SET name = ?, nameEn = ?, description = ?, descriptionEn = ?, image = ?, icon = ?, updatedAt = datetime('now')
      WHERE slug = ?
    `).run(s.name,s.nameEn||"",s.description||"",s.descriptionEn||"",s.image||"",s.icon||"棣冩憹",e),y.getBySlug(e)||null},delete:e=>(0,a.Lf)().prepare("DELETE FROM categories WHERE slug = ?").run(e).changes>0},I={list(){let e=(0,a.Lf)();return e.prepare("SELECT * FROM orders ORDER BY createdAt DESC").all().map(t=>{let r=e.prepare("SELECT * FROM order_items WHERE orderId = ?").all(t.id).map(e=>({id:e.id,productId:e.productId||void 0,name:e.name,nameEn:e.nameEn||"",image:e.image||"",price:e.price,quantity:e.quantity}));return E(t,r)})},getById(e){let t=(0,a.Lf)(),r=t.prepare("SELECT * FROM orders WHERE id = ?").get(e);if(r)return E(r,t.prepare("SELECT * FROM order_items WHERE orderId = ?").all(e).map(e=>({id:e.id,productId:e.productId||void 0,name:e.name,nameEn:e.nameEn||"",image:e.image||"",price:e.price,quantity:e.quantity})))},add(e){let t=(0,a.Lf)();return t.transaction(()=>{t.prepare(`
        INSERT INTO orders (id, orderNo, status, totalAmount, currency, subtotal, discount, couponCode, shipping, customerName, customerEmail, customerPhone,
          shippingName, shippingAddress, shippingCity, shippingState, shippingZip, shippingCountry, paymentMethod, notes, createdAt,
          userEmail, assignedTo, assignedToName, estimatedDeliveryDays, referralCode, referralId, referralVisitorId,
          referredByStaffId, referredByStaffName, attributionClickId, attributionModel, attributionTouchpoints,
          attributionLookbackDays, attributionMatchedBy, attributionFallbackUsed,
          paymentStatus, paypalTransaction, payoneerTransaction, returnInfo)
        VALUES (@id, @orderNo, @status, @totalAmount, @currency, @subtotal, @discount, @couponCode, @shipping, @customerName, @customerEmail, @customerPhone,
          @shippingName, @shippingAddress, @shippingCity, @shippingState, @shippingZip, @shippingCountry, @paymentMethod, @notes, @createdAt,
          @userEmail, @assignedTo, @assignedToName, @estimatedDeliveryDays, @referralCode, @referralId, @referralVisitorId,
          @referredByStaffId, @referredByStaffName, @attributionClickId, @attributionModel, @attributionTouchpoints,
          @attributionLookbackDays, @attributionMatchedBy, @attributionFallbackUsed,
          @paymentStatus, @paypalTransaction, @payoneerTransaction, @returnInfo)
      `).run({id:e.id,orderNo:e.id,status:e.status,totalAmount:e.total,currency:e.currency||"USD",subtotal:e.subtotal,discount:e.discount||0,couponCode:e.couponCode||null,shipping:e.shippingCost,customerName:e.shipping?.firstName?e.shipping.firstName+" "+(e.shipping.lastName||""):e.customerName||"",customerEmail:e.shipping?.email||e.customerEmail||"",customerPhone:e.shipping?.phone||"",shippingName:e.shipping?.firstName?e.shipping.firstName+" "+(e.shipping.lastName||""):"",shippingAddress:e.shipping?.address||"",shippingCity:e.shipping?.city||"",shippingState:e.shipping?.state||"",shippingZip:e.shipping?.zipCode||"",shippingCountry:e.shipping?.country||"United States",paymentMethod:e.paymentMethod||null,notes:e.notes||null,createdAt:e.createdAt,userEmail:e.userEmail||null,assignedTo:e.assignedTo||null,assignedToName:e.assignedToName||null,estimatedDeliveryDays:e.estimatedDeliveryDays||null,referralCode:e.referralCode||null,referralId:e.referralId||null,referralVisitorId:e.referralVisitorId||null,referredByStaffId:e.referredByStaffId||null,referredByStaffName:e.referredByStaffName||null,attributionClickId:e.attributionClickId||null,attributionModel:e.attributionModel||null,attributionTouchpoints:e.attributionTouchpoints||null,attributionLookbackDays:e.attributionLookbackDays||null,attributionMatchedBy:e.attributionMatchedBy||null,attributionFallbackUsed:e.attributionFallbackUsed?1:0,paymentStatus:e.paymentStatus||"unpaid",paypalTransaction:e.paypalTransaction?JSON.stringify(e.paypalTransaction):null,payoneerTransaction:e.payoneerTransaction?JSON.stringify(e.payoneerTransaction):null,returnInfo:e.returnInfo?JSON.stringify(e.returnInfo):null});let r=t.prepare(`
        INSERT INTO order_items (id, orderId, productId, name, nameEn, image, price, quantity, subtotal, category)
        VALUES (@id, @orderId, @productId, @name, @nameEn, @image, @price, @quantity, @subtotal, @category)
      `);e.items.forEach((t,a)=>{r.run({id:"OI-"+e.id+"-"+a+"-"+Math.random().toString(36).slice(2,6),orderId:e.id,productId:t.productId||null,name:t.name,nameEn:t.nameEn||"",image:t.image||"",price:t.price,quantity:t.quantity,subtotal:t.subtotal||t.price*t.quantity,category:t.category||""})});let a=e.status||"pending",i="OSH-"+Date.now().toString(36)+Math.random().toString(36).slice(2,6);t.prepare(`
        INSERT INTO order_status_history (id, orderId, status, note, timestamp)
        VALUES (?, ?, ?, ?, ?)
      `).run(i,e.id,a,"Order placed",e.createdAt||new Date().toISOString())})(),I.getById(e.id)||e},update(e,t){let r=(0,a.Lf)(),i=I.getById(e);return i?(r.transaction(()=>{let a=[],s=[];if(void 0!==t.status&&t.status!==i.status){a.push("status = ?"),s.push(t.status);let i="OSH-"+Date.now().toString(36)+Math.random().toString(36).slice(2,6);r.prepare(`
          INSERT INTO order_status_history (id, orderId, status, note, timestamp)
          VALUES (?, ?, ?, ?, ?)
        `).run(i,e,t.status,t.statusNote||null,new Date().toISOString())}if(void 0!==t.total&&(a.push("totalAmount = ?"),s.push(t.total)),void 0!==t.subtotal&&(a.push("subtotal = ?"),s.push(t.subtotal)),void 0!==t.shippingCost&&(a.push("shipping = ?"),s.push(t.shippingCost)),void 0!==t.currency&&(a.push("currency = ?"),s.push(t.currency)),void 0!==t.notes&&(a.push("notes = ?"),s.push(t.notes||null)),t.tracking?.trackingNumber!==void 0&&(a.push("trackingNumber = ?"),s.push(t.tracking.trackingNumber||null)),t.tracking?.carrier!==void 0&&(a.push("carrier = ?"),s.push(t.tracking.carrier||null)),t.tracking?.estimatedDelivery!==void 0&&(a.push("estimatedDelivery = ?"),s.push(t.tracking.estimatedDelivery||null)),t.tracking?.url!==void 0&&(a.push("trackingUrl = ?"),s.push(t.tracking.url||null)),void 0!==t.assignedTo&&(a.push("assignedTo = ?"),s.push(t.assignedTo||null)),void 0!==t.assignedToName&&(a.push("assignedToName = ?"),s.push(t.assignedToName||null)),void 0!==t.assignedToAvatar&&(a.push("assignedToAvatar = ?"),s.push(t.assignedToAvatar||null)),void 0!==t.userEmail&&(a.push("userEmail = ?"),s.push(t.userEmail||null)),void 0!==t.customerEmail&&(a.push("customerEmail = ?"),s.push(t.customerEmail||null)),void 0!==t.customerName&&(a.push("customerName = ?"),s.push(t.customerName||null)),void 0!==t.estimatedDeliveryDays&&(a.push("estimatedDeliveryDays = ?"),s.push(t.estimatedDeliveryDays||0)),void 0!==t.referralCode&&(a.push("referralCode = ?"),s.push(t.referralCode||null)),void 0!==t.referralId&&(a.push("referralId = ?"),s.push(t.referralId||null)),void 0!==t.referralVisitorId&&(a.push("referralVisitorId = ?"),s.push(t.referralVisitorId||null)),void 0!==t.referredByStaffId&&(a.push("referredByStaffId = ?"),s.push(t.referredByStaffId||null)),void 0!==t.referredByStaffName&&(a.push("referredByStaffName = ?"),s.push(t.referredByStaffName||null)),void 0!==t.attributionClickId&&(a.push("attributionClickId = ?"),s.push(t.attributionClickId||null)),void 0!==t.attributionModel&&(a.push("attributionModel = ?"),s.push(t.attributionModel||null)),void 0!==t.attributionTouchpoints&&(a.push("attributionTouchpoints = ?"),s.push(t.attributionTouchpoints||null)),void 0!==t.attributionLookbackDays&&(a.push("attributionLookbackDays = ?"),s.push(t.attributionLookbackDays||null)),void 0!==t.attributionMatchedBy&&(a.push("attributionMatchedBy = ?"),s.push(t.attributionMatchedBy||null)),void 0!==t.attributionFallbackUsed&&(a.push("attributionFallbackUsed = ?"),s.push(t.attributionFallbackUsed?1:0)),void 0!==t.paymentStatus&&(a.push("paymentStatus = ?"),s.push(t.paymentStatus||"unpaid")),void 0!==t.paypalTransaction&&(a.push("paypalTransaction = ?"),s.push(t.paypalTransaction?JSON.stringify(t.paypalTransaction):null)),void 0!==t.payoneerTransaction&&(a.push("payoneerTransaction = ?"),s.push(t.payoneerTransaction?JSON.stringify(t.payoneerTransaction):null)),void 0!==t.returnInfo&&(a.push("returnInfo = ?"),s.push(t.returnInfo?JSON.stringify(t.returnInfo):null)),void 0!==t.paymentMethod&&(a.push("paymentMethod = ?"),s.push(t.paymentMethod||null)),void 0!==t.shippingMethod&&(a.push("shippingMethod = ?"),s.push(t.shippingMethod||null)),void 0!==t.couponCode&&(a.push("couponCode = ?"),s.push(t.couponCode||null)),void 0!==t.discount&&(a.push("discount = ?"),s.push(t.discount||0)),void 0!==t.tax&&(a.push("tax = ?"),s.push(t.tax||0)),t.shipping){let e=t.shipping;if(void 0!==e.firstName||void 0!==e.lastName){let t=[e.firstName||"",e.lastName||""].filter(Boolean).join(" ");a.push("shippingName = ?"),s.push(t||null)}void 0!==e.address&&(a.push("shippingAddress = ?"),s.push(e.address||null)),void 0!==e.city&&(a.push("shippingCity = ?"),s.push(e.city||null)),void 0!==e.state&&(a.push("shippingState = ?"),s.push(e.state||null)),void 0!==e.zipCode&&(a.push("shippingZip = ?"),s.push(e.zipCode||null)),void 0!==e.country&&(a.push("shippingCountry = ?"),s.push(e.country||null)),void 0!==e.phone&&(a.push("customerPhone = ?"),s.push(e.phone||null))}if(t.billing){let e=t.billing;if(void 0!==e.firstName||void 0!==e.lastName){let t=[e.firstName||"",e.lastName||""].filter(Boolean).join(" ");a.push("billingName = ?"),s.push(t||null)}void 0!==e.address&&(a.push("billingAddress = ?"),s.push(e.address||null)),void 0!==e.city&&(a.push("billingCity = ?"),s.push(e.city||null)),void 0!==e.state&&(a.push("billingState = ?"),s.push(e.state||null)),void 0!==e.zipCode&&(a.push("billingZip = ?"),s.push(e.zipCode||null)),void 0!==e.country&&(a.push("billingCountry = ?"),s.push(e.country||null))}void 0!==t.userId&&(a.push("userId = ?"),s.push(t.userId||null)),a.length>0&&(a.push("updatedAt = datetime('now')"),s.push(e),r.prepare(`UPDATE orders SET ${a.join(", ")} WHERE id = ?`).run(...s))})(),I.getById(e)||null):null},updateStatus:(e,t,r)=>I.update(e,{status:t,statusNote:r}),updateTracking:(e,t)=>I.update(e,{tracking:t}),updateNotes:(e,t)=>I.update(e,{notes:t}),assignStaff:(e,t,r,a)=>I.update(e,{assignedTo:t,assignedToName:r})},S={list(){let e=(0,a.Lf)();return e.prepare("SELECT * FROM users ORDER BY createdAt DESC").all().map(t=>{let r=e.prepare("SELECT * FROM user_addresses WHERE userId = ? ORDER BY isDefault DESC, createdAt").all(t.id).map(e=>({id:e.id,label:e.label||"",firstName:e.firstName||"",lastName:e.lastName||"",phone:e.phone||"",address:e.address||"",city:e.city||"",state:e.state||"",zip:e.zip||"",country:e.country||"United States",isDefault:!!e.isDefault})),a=e.prepare("SELECT productId FROM wishlist WHERE userId = ? ORDER BY createdAt DESC").all(t.id).map(e=>e.productId);return T(t,r,a)})},getById(e){let t=(0,a.Lf)(),r=t.prepare("SELECT * FROM users WHERE id = ?").get(e);if(r)return T(r,t.prepare("SELECT * FROM user_addresses WHERE userId = ? ORDER BY isDefault DESC, createdAt").all(e).map(e=>({id:e.id,label:e.label||"",firstName:e.firstName||"",lastName:e.lastName||"",phone:e.phone||"",address:e.address||"",city:e.city||"",state:e.state||"",zip:e.zip||"",country:e.country||"United States",isDefault:!!e.isDefault})),t.prepare("SELECT productId FROM wishlist WHERE userId = ? ORDER BY createdAt DESC").all(e).map(e=>e.productId))},getByEmail(e){let t=(0,a.Lf)().prepare("SELECT * FROM users WHERE email = ?").get(e);if(t)return S.getById(t.id)},getByToken(e){let t=(0,a.Lf)().prepare("SELECT * FROM users WHERE token = ?").get(e);if(t&&!(t.tokenExpiresAt&&new Date(t.tokenExpiresAt).getTime()<Date.now()))return S.getById(t.id)},add(e){let t=(0,a.Lf)();if(t.prepare(`
      INSERT INTO users (id, email, passwordHash, salt, firstName, lastName, phone, avatar, dob, gender, bio, preferredCurrency, coupons, role, token, tokenExpiresAt, createdAt, updatedAt)
      VALUES (@id, @email, @passwordHash, @salt, @firstName, @lastName, @phone, @avatar, @dob, @gender, @bio, @preferredCurrency, @coupons, @role, @token, @tokenExpiresAt, @createdAt, @updatedAt)
    `).run({id:e.id,email:e.email,passwordHash:e.passwordHash,salt:e.salt,firstName:e.firstName||"",lastName:e.lastName||"",phone:e.phone||"",avatar:e.avatar||null,dob:e.dob||null,gender:e.gender||null,bio:e.bio||null,preferredCurrency:e.preferredCurrency||"USD",coupons:e.coupons&&e.coupons.length?JSON.stringify(e.coupons):null,role:e.role||"customer",token:e.token||null,tokenExpiresAt:e.tokenExpiresAt||null,createdAt:e.createdAt,updatedAt:e.updatedAt||e.createdAt}),e.addresses?.length){let r=t.prepare(`
        INSERT INTO user_addresses (id, userId, label, firstName, lastName, phone, address, city, state, zip, country, isDefault)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);e.addresses.forEach(t=>r.run(t.id,e.id,t.label,t.firstName,t.lastName,t.phone,t.address,t.city,t.state,t.zip,t.country,t.isDefault?1:0))}if(e.wishlist?.length){let r=t.prepare("INSERT OR IGNORE INTO wishlist (userId, productId) VALUES (?, ?)");e.wishlist.forEach(t=>r.run(e.id,t))}return e},update(e,t){let r=(0,a.Lf)(),i=S.getById(e);if(!i)return null;let s={...i,...t};if(r.prepare(`
      UPDATE users SET firstName = ?, lastName = ?, phone = ?, avatar = ?, dob = ?, gender = ?, bio = ?,
        coupons = ?,
        preferredCurrency = ?, role = ?, token = ?, tokenExpiresAt = ?, updatedAt = datetime('now')
      WHERE id = ?
    `).run(s.firstName||"",s.lastName||"",s.phone||"",s.avatar||null,s.dob||null,s.gender||null,s.bio||null,s.coupons&&s.coupons.length?JSON.stringify(s.coupons):null,s.preferredCurrency||"USD",s.role||"customer",s.token||null,void 0!==t.tokenExpiresAt?t.tokenExpiresAt:s.tokenExpiresAt||null,e),t.addresses){r.prepare("DELETE FROM user_addresses WHERE userId = ?").run(e);let a=r.prepare(`
        INSERT INTO user_addresses (id, userId, label, firstName, lastName, phone, address, city, state, zip, country, isDefault)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);t.addresses.forEach(t=>a.run(t.id,e,t.label,t.firstName,t.lastName,t.phone,t.address,t.city,t.state,t.zip,t.country,t.isDefault?1:0))}if(t.wishlist){r.prepare("DELETE FROM wishlist WHERE userId = ?").run(e);let a=r.prepare("INSERT INTO wishlist (userId, productId) VALUES (?, ?)");t.wishlist.forEach(t=>a.run(e,t))}return S.getById(e)||null}},A={list:()=>(0,a.Lf)().prepare("SELECT * FROM reviews ORDER BY createdAt DESC").all().map(g),getByProduct:e=>(0,a.Lf)().prepare("SELECT * FROM reviews WHERE productId = ? ORDER BY createdAt DESC").all(e).map(g),add(e){let t=(0,a.Lf)(),r="REV-"+Date.now().toString(36).toUpperCase(),i=e.date||new Date().toLocaleDateString("en-US",{year:"numeric",month:"long",day:"numeric"}),s=e.avatar||(e.author||"A")[0].toUpperCase();return t.prepare(`
      INSERT INTO reviews (id, productId, author, avatar, rating, date, content, location, approved, orderId, customerEmail, source)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(r,e.productId,e.author||"Anonymous",s,e.rating,i,e.content||"",e.location||"Verified Buyer",e.approved?1:0,e.orderId||null,e.customerEmail||null,e.source||"customer"),t.prepare("UPDATE products SET reviewCount = (SELECT COUNT(*) FROM reviews WHERE productId = products.id) WHERE id = ?").run(e.productId),{...e,id:r,date:i,avatar:s,approved:!!e.approved,hidden:!1,deleted:!1,createdAt:new Date().toISOString()}},update(e,t){let r=(0,a.Lf)(),i=A.list().find(t=>t.id===e);return i?(r.prepare(`
      UPDATE reviews SET author = ?, rating = ?, content = ?, location = ?, approved = ?, hidden = ?, deleted = ?, avatar = ?, date = ?
      WHERE id = ?
    `).run(t.author||i.author,t.rating??i.rating,t.content||i.content,t.location||i.location,void 0!==t.approved?t.approved?1:0:i.approved?1:0,void 0!==t.hidden?t.hidden?1:0:i.hidden?1:0,void 0!==t.deleted?t.deleted?1:0:i.deleted?1:0,t.avatar||i.avatar,t.date||i.date,e),A.list().find(t=>t.id===e)||null):null}};function N(e){if(!e)return[];if(Array.isArray(e))return e;try{return JSON.parse(e)}catch{return[]}}function b(e,t){return{id:e.id,name:t?.name||e.name||"",email:e.email||"",phone:e.phone||"",subject:e.subject||"",message:e.message||"",avatar:e.avatar||t?.avatar||void 0,registered:t?.registered||!1,status:e.status||"unread",createdAt:e.createdAt,source:e.source||"",attachments:N(e.attachments),adminReply:e.adminReply||"",adminAttachments:N(e.adminAttachments),adminName:e.adminName||"",adminAvatar:e.adminAvatar||"",repliedAt:e.repliedAt||"",read:!!e.read||"read"===e.status,replied:!!e.replied||"replied"===e.status,senderType:e.senderType||"customer",adminRead:!!e.adminRead,chatType:e.chatType||void 0,fromStaffId:e.fromStaffId||void 0,toStaffId:e.toStaffId||void 0,fromAvatar:e.fromAvatar||void 0,fromName:e.fromName||void 0,toAvatar:e.toAvatar||void 0,toName:e.toName||void 0,orderRef:e.orderRef?JSON.parse(e.orderRef):void 0}}function v(e,t){if(!t)return{registered:!1};let r=e.prepare("SELECT avatar, firstName, lastName FROM users WHERE email = ?").get(t.toLowerCase());if(!r)return{registered:!1};let a=[r.firstName,r.lastName].filter(Boolean).join(" ");return{avatar:r.avatar||void 0,name:a||void 0,registered:!0}}let L={list(){let e=(0,a.Lf)(),t=e.prepare("SELECT * FROM messages ORDER BY createdAt DESC").all(),r=new Map;return t.map(t=>{let a=t.email?.toLowerCase(),i=r.get(a);return!i&&t.email&&(i=v(e,t.email),r.set(a,i)),b(t,i)})},getById(e){let t=(0,a.Lf)(),r=t.prepare("SELECT * FROM messages WHERE id = ?").get(e);if(!r)return;let i=v(t,r.email);return b(r,i)},add(e){let t=(0,a.Lf)(),r=e.id||"MSG-"+Date.now().toString(36).toUpperCase(),i=e.createdAt||new Date().toISOString(),s=e.status||"unread",o=JSON.stringify(e.attachments||[]),n=e.read?1:0,d=e.replied?1:0,l=e.senderType||"customer",u=e.adminRead?1:0,p=e.orderRef?JSON.stringify(e.orderRef):null;return t.prepare(`
      INSERT INTO messages (id, name, email, phone, subject, message, status, createdAt, source, attachments, adminReply, adminAttachments, adminName, adminAvatar, repliedAt, read, replied, senderType, adminRead, avatar, chatType, fromStaffId, toStaffId, fromAvatar, fromName, toAvatar, toName, orderRef)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(r,e.name||"",e.email||"",e.phone||"",e.subject||"",e.message||"",s,i,e.source||"",o,e.adminReply||"",JSON.stringify(e.adminAttachments||[]),e.adminName||"",e.adminAvatar||"",e.repliedAt||"",n,d,l,u,e.avatar||"",e.chatType||"",e.fromStaffId||"",e.toStaffId||"",e.fromAvatar||"",e.fromName||"",e.toAvatar||"",e.toName||"",p),L.getById(r)},update(e,t){let r=(0,a.Lf)();if(!L.getById(e))return null;let i=[],s=[];return void 0!==t.name&&(i.push("name = ?"),s.push(t.name)),void 0!==t.email&&(i.push("email = ?"),s.push(t.email)),void 0!==t.phone&&(i.push("phone = ?"),s.push(t.phone)),void 0!==t.subject&&(i.push("subject = ?"),s.push(t.subject)),void 0!==t.message&&(i.push("message = ?"),s.push(t.message)),void 0!==t.status&&(i.push("status = ?"),s.push(t.status)),void 0!==t.source&&(i.push("source = ?"),s.push(t.source)),void 0!==t.attachments&&(i.push("attachments = ?"),s.push(JSON.stringify(t.attachments))),void 0!==t.adminReply&&(i.push("adminReply = ?"),s.push(t.adminReply)),void 0!==t.adminAttachments&&(i.push("adminAttachments = ?"),s.push(JSON.stringify(t.adminAttachments))),void 0!==t.adminName&&(i.push("adminName = ?"),s.push(t.adminName)),void 0!==t.adminAvatar&&(i.push("adminAvatar = ?"),s.push(t.adminAvatar)),void 0!==t.repliedAt&&(i.push("repliedAt = ?"),s.push(t.repliedAt)),void 0!==t.read&&(i.push("read = ?"),s.push(t.read?1:0)),void 0!==t.replied&&(i.push("replied = ?"),s.push(t.replied?1:0)),void 0!==t.senderType&&(i.push("senderType = ?"),s.push(t.senderType)),void 0!==t.adminRead&&(i.push("adminRead = ?"),s.push(t.adminRead?1:0)),void 0!==t.avatar&&(i.push("avatar = ?"),s.push(t.avatar)),void 0!==t.chatType&&(i.push("chatType = ?"),s.push(t.chatType)),void 0!==t.fromStaffId&&(i.push("fromStaffId = ?"),s.push(t.fromStaffId)),void 0!==t.toStaffId&&(i.push("toStaffId = ?"),s.push(t.toStaffId)),void 0!==t.fromAvatar&&(i.push("fromAvatar = ?"),s.push(t.fromAvatar)),void 0!==t.fromName&&(i.push("fromName = ?"),s.push(t.fromName)),void 0!==t.toAvatar&&(i.push("toAvatar = ?"),s.push(t.toAvatar)),void 0!==t.toName&&(i.push("toName = ?"),s.push(t.toName)),void 0!==t.orderRef&&(i.push("orderRef = ?"),s.push(JSON.stringify(t.orderRef))),i.length>0&&(s.push(e),r.prepare(`UPDATE messages SET ${i.join(", ")} WHERE id = ?`).run(...s)),L.getById(e)||null}},R="site_settings",O={get(){let e=(0,a.Lf)().prepare("SELECT value FROM settings WHERE key = ?").get(R);if(e&&e.value)try{return(0,i.normalizeSavedSettings)(JSON.parse(e.value))}catch{}return i.DEFAULTS},update(e){let t=(0,a.Lf)(),i=O.get(),s={...i,...e,frontendContent:e.frontendContent?{...i.frontendContent,...e.frontendContent}:i.frontendContent};t.prepare(`
      INSERT OR REPLACE INTO settings (key, value, updatedAt)
      VALUES (?, ?, datetime('now'))
    `).run(R,JSON.stringify(s));try{r(51105).gm("settings")}catch{}return s}},C={list:()=>O.get().staffMembers||[],getById:e=>C.list().find(t=>t.id===e),getByEmail:e=>C.list().find(t=>t.email.toLowerCase()===e.toLowerCase()),add(e){let t=O.get().staffMembers||[],r={...e,id:e.id||"STF-"+Date.now().toString(36).toUpperCase(),createdAt:e.createdAt||new Date().toISOString()};return t.push(r),O.update({staffMembers:t}),r},update(e,t){let r=O.get().staffMembers||[],a=r.findIndex(t=>t.id===e);return -1===a?null:(r[a]={...r[a],...t},O.update({staffMembers:r}),r[a])},delete(e){let t=O.get().staffMembers||[],r=t.length,a=t.filter(t=>t.id!==e);return a.length!==r&&(O.update({staffMembers:a}),!0)}},D={list:()=>(0,a.Lf)().prepare("SELECT * FROM newsletter_subscribers ORDER BY createdAt DESC").all().map(e=>({id:e.id,email:e.email,status:e.status||"active",createdAt:e.createdAt,subscribedAt:e.createdAt,source:e.source||""})),getByEmail(e){let t=(0,a.Lf)().prepare("SELECT * FROM newsletter_subscribers WHERE email = ?").get(e.toLowerCase());if(t)return{id:t.id,email:t.email,status:t.status||"active",createdAt:t.createdAt,subscribedAt:t.createdAt,source:t.source||""}},add(e,t="footer"){let r=(0,a.Lf)(),i=e.toLowerCase().trim(),s=D.getByEmail(i);if(s)return s;let o="NL-"+Date.now().toString(36).toUpperCase(),n=new Date().toISOString();return r.prepare(`
      INSERT INTO newsletter_subscribers (id, email, status, createdAt)
      VALUES (?, ?, 'active', ?)
    `).run(o,i,n),{id:o,email:i,status:"active",createdAt:n,subscribedAt:n,source:t}},delete:e=>(0,a.Lf)().prepare("DELETE FROM newsletter_subscribers WHERE id = ?").run(e).changes>0},w={list:()=>(0,a.Lf)().prepare("SELECT * FROM work_logs ORDER BY timestamp DESC").all().map(e=>({id:e.id,timestamp:e.timestamp,operatorId:e.operatorId||"",operatorName:e.operatorName||"",operatorRole:e.operatorRole||"",action:e.action||"",details:e.details||"",orderId:e.orderId||void 0,productId:e.productId||void 0,category:e.category||void 0})),add(e){let t=(0,a.Lf)(),r=e.id||"WL-"+Date.now().toString(36).toUpperCase()+"-"+Math.random().toString(36).slice(2,6).toUpperCase(),i=e.timestamp||new Date().toISOString();return t.prepare(`
      INSERT INTO work_logs (id, timestamp, operatorId, operatorName, operatorRole, action, details, orderId, productId, category)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(r,i,e.operatorId||null,e.operatorName||null,e.operatorRole||null,e.action||null,e.details||null,e.orderId||null,e.productId||null,e.category||null),{...e,id:r,timestamp:i,operatorId:e.operatorId||"",operatorName:e.operatorName||"",operatorRole:e.operatorRole||"",action:e.action||"",details:e.details||""}}},U={list:()=>(0,a.Lf)().prepare("SELECT * FROM browsing_history ORDER BY timestamp DESC").all().map(e=>({id:e.id,sessionId:e.sessionId,userId:e.userId||void 0,email:e.email||"",visitorId:e.visitorId,productId:e.productId,productName:e.productName||"",productImage:e.productImage||"",productPrice:e.productPrice||0,productCode:e.productCode||"",productCategory:e.productCategory||"",pageType:e.pageType||"product",duration:e.duration||0,ip:e.ip||"",timestamp:e.timestamp})),getByEmail:e=>(0,a.Lf)().prepare("SELECT * FROM browsing_history WHERE email = ? ORDER BY timestamp DESC").all(e.toLowerCase()).map(e=>({id:e.id,sessionId:e.sessionId,userId:e.userId||void 0,email:e.email||"",visitorId:e.visitorId,productId:e.productId,productName:e.productName||"",productImage:e.productImage||"",productPrice:e.productPrice||0,productCode:e.productCode||"",productCategory:e.productCategory||"",pageType:e.pageType||"product",duration:e.duration||0,ip:e.ip||"",timestamp:e.timestamp})),getByVisitor:e=>(0,a.Lf)().prepare("SELECT * FROM browsing_history WHERE visitorId = ? ORDER BY timestamp DESC").all(e).map(e=>({id:e.id,sessionId:e.sessionId,userId:e.userId||void 0,email:e.email||"",visitorId:e.visitorId,productId:e.productId,productName:e.productName||"",productImage:e.productImage||"",productPrice:e.productPrice||0,productCode:e.productCode||"",productCategory:e.productCategory||"",pageType:e.pageType||"product",duration:e.duration||0,ip:e.ip||"",timestamp:e.timestamp})),add(e){let t=(0,a.Lf)(),r=t.prepare(`
      SELECT * FROM browsing_history
      WHERE visitorId = ? AND productId = ?
        AND strftime('%s', timestamp) > strftime('%s', 'now', '-30 seconds')
      ORDER BY timestamp DESC LIMIT 1
    `).get(e.visitorId,e.productId);if(r){if((e.userId||e.email)&&(!r.userId||!r.email)){let a=[],i=[];e.userId&&!r.userId&&(a.push("userId = ?"),i.push(e.userId)),e.email&&!r.email&&(a.push("email = ?"),i.push(e.email.toLowerCase())),a.length>0&&(i.push(r.id),t.prepare(`UPDATE browsing_history SET ${a.join(", ")} WHERE id = ?`).run(...i))}return{id:r.id,sessionId:r.sessionId,userId:r.userId||void 0,email:r.email||"",visitorId:r.visitorId,productId:r.productId,productName:r.productName||"",productImage:r.productImage||"",productPrice:r.productPrice||0,productCode:r.productCode||"",productCategory:r.productCategory||"",pageType:r.pageType||"product",duration:r.duration||0,ip:r.ip||"",timestamp:r.timestamp}}let i="BH-"+Date.now().toString(36).toUpperCase()+"-"+Math.random().toString(36).slice(2,6).toUpperCase(),s=new Date().toISOString();return t.prepare(`
      INSERT INTO browsing_history (id, sessionId, userId, email, visitorId, productId, productName, productImage, productPrice, productCode, productCategory, pageType, duration, ip, timestamp)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(i,e.sessionId,e.userId||null,(e.email||"").toLowerCase(),e.visitorId,e.productId,e.productName||"",e.productImage||"",e.productPrice||0,e.productCode||"",e.productCategory||"",e.pageType||"product",e.duration||0,e.ip||"",s),{...e,id:i,timestamp:s}},update(e,t){let r=(0,a.Lf)(),i=[],s=[];void 0!==t.duration&&(i.push("duration = ?"),s.push(t.duration)),void 0!==t.email&&(i.push("email = ?"),s.push(t.email.toLowerCase())),void 0!==t.userId&&(i.push("userId = ?"),s.push(t.userId||null)),i.length>0&&(s.push(e),r.prepare(`UPDATE browsing_history SET ${i.join(", ")} WHERE id = ?`).run(...s));let o=r.prepare("SELECT * FROM browsing_history WHERE id = ?").get(e);return o?{id:o.id,sessionId:o.sessionId,userId:o.userId||void 0,email:o.email||"",visitorId:o.visitorId,productId:o.productId,productName:o.productName||"",productImage:o.productImage||"",productPrice:o.productPrice||0,productCode:o.productCode||"",productCategory:o.productCategory||"",pageType:o.pageType||"product",duration:o.duration||0,ip:o.ip||"",timestamp:o.timestamp}:null},cleanupOld:(e=90)=>(0,a.Lf)().prepare(`DELETE FROM browsing_history WHERE timestamp < datetime('now', '-${e} days')`).run().changes},X={list:()=>(0,a.Lf)().prepare("SELECT * FROM customers ORDER BY totalSpent DESC, lastOrderAt DESC").all().map(e=>({id:e.id,email:e.email,firstName:e.firstName||"",lastName:e.lastName||"",phone:e.phone||"",avatar:e.avatar||void 0,rating:e.rating||0,tier:e.tier||"standard",notes:e.notes||"",preferences:e.preferences?JSON.parse(e.preferences):[],tags:e.tags?JSON.parse(e.tags):[],totalOrders:e.totalOrders||0,totalSpent:e.totalSpent||0,lastOrderAt:e.lastOrderAt||"",createdAt:e.createdAt,updatedAt:e.updatedAt})),getById(e){let t=(0,a.Lf)().prepare("SELECT * FROM customers WHERE id = ?").get(e);if(t)return{id:t.id,email:t.email,firstName:t.firstName||"",lastName:t.lastName||"",phone:t.phone||"",avatar:t.avatar||void 0,rating:t.rating||0,tier:t.tier||"standard",notes:t.notes||"",preferences:t.preferences?JSON.parse(t.preferences):[],tags:t.tags?JSON.parse(t.tags):[],totalOrders:t.totalOrders||0,totalSpent:t.totalSpent||0,lastOrderAt:t.lastOrderAt||"",createdAt:t.createdAt,updatedAt:t.updatedAt}},getByEmail(e){let t=(0,a.Lf)().prepare("SELECT * FROM customers WHERE email = ?").get(e.toLowerCase());if(t)return{id:t.id,email:t.email,firstName:t.firstName||"",lastName:t.lastName||"",phone:t.phone||"",avatar:t.avatar||void 0,rating:t.rating||0,tier:t.tier||"standard",notes:t.notes||"",preferences:t.preferences?JSON.parse(t.preferences):[],tags:t.tags?JSON.parse(t.tags):[],totalOrders:t.totalOrders||0,totalSpent:t.totalSpent||0,lastOrderAt:t.lastOrderAt||"",createdAt:t.createdAt,updatedAt:t.updatedAt}},add(e){let t=(0,a.Lf)(),r=e.id||"CUS-"+Date.now().toString(36).toUpperCase()+"-"+Math.random().toString(36).slice(2,6).toUpperCase(),i=new Date().toISOString();return t.prepare(`
      INSERT INTO customers (id, email, firstName, lastName, phone, avatar, rating, tier, notes, preferences, tags, totalOrders, totalSpent, lastOrderAt, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(r,e.email.toLowerCase(),e.firstName||"",e.lastName||"",e.phone||"",e.avatar||null,e.rating||0,e.tier||"standard",e.notes||"",JSON.stringify(e.preferences||[]),JSON.stringify(e.tags||[]),e.totalOrders||0,e.totalSpent||0,e.lastOrderAt||null,i,i),X.getById(r)},update(e,t){let r=(0,a.Lf)();if(!X.getById(e))return null;let i=[],s=[];return void 0!==t.firstName&&(i.push("firstName = ?"),s.push(t.firstName)),void 0!==t.lastName&&(i.push("lastName = ?"),s.push(t.lastName)),void 0!==t.phone&&(i.push("phone = ?"),s.push(t.phone)),void 0!==t.avatar&&(i.push("avatar = ?"),s.push(t.avatar||null)),void 0!==t.rating&&(i.push("rating = ?"),s.push(t.rating)),void 0!==t.tier&&(i.push("tier = ?"),s.push(t.tier)),void 0!==t.notes&&(i.push("notes = ?"),s.push(t.notes)),void 0!==t.preferences&&(i.push("preferences = ?"),s.push(JSON.stringify(t.preferences))),void 0!==t.tags&&(i.push("tags = ?"),s.push(JSON.stringify(t.tags))),void 0!==t.totalOrders&&(i.push("totalOrders = ?"),s.push(t.totalOrders)),void 0!==t.totalSpent&&(i.push("totalSpent = ?"),s.push(t.totalSpent)),void 0!==t.lastOrderAt&&(i.push("lastOrderAt = ?"),s.push(t.lastOrderAt||null)),i.length>0&&(i.push("updatedAt = datetime('now')"),s.push(e),r.prepare(`UPDATE customers SET ${i.join(", ")} WHERE id = ?`).run(...s)),X.getById(e)||null},upsertByEmail(e,t){let r=X.getByEmail(e);return r?X.update(r.id,t):X.add({...t,email:e})},syncFromOrders(){(0,a.Lf)();let e=I.list(),t={},r=(0,i.getSettings)().customerTiers||i.DEFAULTS.customerTiers;e.forEach(e=>{let r=(e.customerEmail||e.shipping?.email||"").toLowerCase();r&&(t[r]||(t[r]={orders:[],total:0,lastOrder:""}),t[r].orders.push(e),t[r].total+=e.total||0,(!t[r].lastOrder||e.createdAt>t[r].lastOrder)&&(t[r].lastOrder=e.createdAt))}),Object.entries(t).forEach(([e,t])=>{let a=t.orders[0],i=X.getByEmail(e),s=r.find(e=>t.orders.length>=e.minOrders&&t.orders.length<=e.maxOrders)||r[0],o={totalOrders:t.orders.length,totalSpent:t.total,lastOrderAt:t.lastOrder,tier:s.id,rating:s.stars};i?X.update(i.id,o):(o.firstName=a.customerName?.split(" ")[0]||a.shipping?.firstName||"",o.lastName=a.customerName?.split(" ").slice(1).join(" ")||a.shipping?.lastName||"",o.phone=a.customerPhone||a.shipping?.phone||"",X.add({...o,email:e}))})}};function F(e){return{id:e.id,orderId:e.orderId,orderNo:e.orderNo||"",shipmentNo:e.shipmentNo||"",carrierCode:e.carrierCode||"",carrierName:e.carrierName||"",trackingNumber:e.trackingNumber||"",status:e.status||"pending",weight:e.weight||void 0,shippingCost:e.shippingCost||void 0,shippedAt:e.shippedAt||"",estimatedDelivery:e.estimatedDelivery||"",deliveredAt:e.deliveredAt||"",events:e.events?JSON.parse(e.events):[],notes:e.notes||"",createdBy:e.createdBy||"",notifiedAt:e.notifiedAt||"",notifiedChannel:e.notifiedChannel||"",notifiedTo:e.notifiedTo||"",createdAt:e.createdAt,updatedAt:e.updatedAt}}let k={list:()=>(0,a.Lf)().prepare("SELECT * FROM shipments ORDER BY createdAt DESC").all().map(F),getByOrderId:e=>(0,a.Lf)().prepare("SELECT * FROM shipments WHERE orderId = ? ORDER BY createdAt ASC").all(e).map(F),getByTrackingNumber(e){let t=(0,a.Lf)().prepare("SELECT * FROM shipments WHERE trackingNumber = ?").get(e);return t?F(t):null},getById(e){let t=(0,a.Lf)().prepare("SELECT * FROM shipments WHERE id = ?").get(e);return t?F(t):null},add(e){let t=(0,a.Lf)(),r="SHP-"+Date.now().toString(36).toUpperCase()+"-"+Math.random().toString(36).slice(2,6).toUpperCase(),i=new Date().toISOString(),s=e.shippedAt||i;return t.prepare(`
      INSERT INTO shipments (id, orderId, orderNo, shipmentNo, carrierCode, carrierName, trackingNumber, status, weight, shippingCost, shippedAt, estimatedDelivery, events, notes, createdBy, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(r,e.orderId,e.orderNo||"",e.shipmentNo,e.carrierCode,e.carrierName||"",e.trackingNumber,e.status||"picked_up",e.weight||null,e.shippingCost||null,s,e.estimatedDelivery||"",JSON.stringify(e.events||[]),e.notes||"",e.createdBy||"",i,i),k.getById(r)},update(e,t){let r=(0,a.Lf)(),i=k.getById(e);if(!i)return null;let s=[],o=[],n=(e,t)=>{void 0!==t&&(s.push(`${e} = ?`),o.push(t))};return n("carrierCode",t.carrierCode),n("carrierName",t.carrierName),n("trackingNumber",t.trackingNumber),n("status",t.status),n("weight",t.weight),n("shippingCost",t.shippingCost),n("estimatedDelivery",t.estimatedDelivery),n("deliveredAt",t.deliveredAt),n("notes",t.notes),n("notifiedAt",t.notifiedAt),n("notifiedChannel",t.notifiedChannel),n("notifiedTo",t.notifiedTo),void 0!==t.events&&(s.push("events = ?"),o.push(JSON.stringify(t.events))),"delivered"!==t.status||t.deliveredAt||i.deliveredAt||(s.push("deliveredAt = ?"),o.push(new Date().toISOString())),s.length>0&&(s.push("updatedAt = datetime('now')"),o.push(e),r.prepare(`UPDATE shipments SET ${s.join(", ")} WHERE id = ?`).run(...o)),k.getById(e)},addTrackEvent(e,t){let r=k.getById(e);if(!r)return null;let a={id:"EVT-"+Date.now().toString(36).toUpperCase()+"-"+Math.random().toString(36).slice(2,6).toUpperCase(),...t},i=[...r.events||[],a];return i.sort((e,t)=>new Date(e.timestamp).getTime()-new Date(t.timestamp).getTime()),k.update(e,{events:i,status:t.status})},delete:e=>(0,a.Lf)().prepare("DELETE FROM shipments WHERE id = ?").run(e).changes>0,cancel(e,t,r){let i=(0,a.Lf)(),s=k.getById(e);if(!s)return null;if(["delivered","returned","cancelled"].includes(s.status))throw Error(`Cannot cancel shipment with status: ${s.status}`);if(!I.getById(s.orderId))throw Error("Order not found");let o=new Date().toISOString(),n=t||"Shipment cancelled",d=k.getByOrderId(s.orderId).filter(t=>t.id!==e&&!["cancelled","delivered","returned"].includes(t.status)).length>0;return i.transaction(()=>{let t={id:"EVT-"+Date.now().toString(36).toUpperCase()+"-"+Math.random().toString(36).slice(2,6).toUpperCase(),timestamp:o,location:"",description:n,status:"cancelled",carrier:s.carrierCode,operator:r||""},a=[...s.events||[],t],l=["status = ?","events = ?","updatedAt = datetime('now')"],u=["cancelled",JSON.stringify(a)];if(s.notes?(l.push("notes = ?"),u.push(s.notes+"\n[cancelled] "+n)):(l.push("notes = ?"),u.push("[cancelled] "+n)),u.push(e),i.prepare(`UPDATE shipments SET ${l.join(", ")} WHERE id = ?`).run(...u),!d){let e=["status = ?"],t=["processing"],r="OSH-"+Date.now().toString(36)+Math.random().toString(36).slice(2,6);i.prepare(`
          INSERT INTO order_status_history (id, orderId, status, note, timestamp)
          VALUES (?, ?, ?, ?, ?)
        `).run(r,s.orderId,"processing",`Shipment ${s.shipmentNo||s.id.slice(0,12)} cancelled: ${n}`,o),e.push("trackingNumber = ?"),t.push(null),e.push("carrier = ?"),t.push(null),e.push("trackingUrl = ?"),t.push(null),t.push(s.orderId),i.prepare(`UPDATE orders SET ${e.join(", ")} WHERE id = ?`).run(...t)}return{shipment:k.getById(e),order:I.getById(s.orderId),orderReverted:!d}})()},hasActiveShipment:e=>k.getByOrderId(e).some(e=>!["cancelled","delivered","returned"].includes(e.status)),getStats(){let e=(0,a.Lf)(),t=e.prepare("SELECT COUNT(*) as c FROM shipments").get().c,r=e.prepare("SELECT COUNT(*) as c FROM shipments WHERE status IN ('picked_up','in_transit','export_customs','international','import_customs','at_local_facility','out_for_delivery')").get().c;return{total:t,inTransit:r,delivered:e.prepare("SELECT COUNT(*) as c FROM shipments WHERE status = 'delivered'").get().c,pending:e.prepare("SELECT COUNT(*) as c FROM shipments WHERE status = 'pending'").get().c,cancelled:e.prepare("SELECT COUNT(*) as c FROM shipments WHERE status = 'cancelled'").get().c}}};(0,a.s4)()},18084:(e,t,r)=>{r.d(t,{Lf:()=>c,s4:()=>E});var a=r(87550),i=r.n(a),s=r(33873),o=r.n(s),n=r(29021),d=r.n(n);let l=null,u=o().join(process.cwd(),"data"),p=o().join(u,"site.db");function c(){return l||(d().existsSync(u)||d().mkdirSync(u,{recursive:!0}),(l=new(i())(p)).pragma("journal_mode = WAL"),l.pragma("foreign_keys = ON")),l}function E(){let e=c();e.exec(`
    -- 分类表
    CREATE TABLE IF NOT EXISTS categories (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      nameEn TEXT,
      slug TEXT UNIQUE NOT NULL,
      description TEXT,
      descriptionEn TEXT,
      image TEXT,
      icon TEXT,
      iconType TEXT DEFAULT 'emoji',
      sortOrder INTEGER DEFAULT 0,
      productCount INTEGER DEFAULT 0,
      parentId TEXT,
      active INTEGER DEFAULT 1,
      createdAt TEXT DEFAULT (datetime('now')),
      updatedAt TEXT DEFAULT (datetime('now'))
    );

    -- 供货商表
    CREATE TABLE IF NOT EXISTS suppliers (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      contact TEXT,
      phone TEXT,
      email TEXT,
      address TEXT,
      region TEXT,
      status TEXT DEFAULT 'active',
      notes TEXT,
      createdAt TEXT DEFAULT (datetime('now')),
      updatedAt TEXT DEFAULT (datetime('now'))
    );

    -- 商品表
    CREATE TABLE IF NOT EXISTS products (
      id TEXT PRIMARY KEY,
      code TEXT UNIQUE,
      name TEXT NOT NULL,
      nameEn TEXT,
      subtitle TEXT,
      subtitleEn TEXT,
      description TEXT,
      descriptionEn TEXT,
      story TEXT,
      storyEn TEXT,
      price REAL NOT NULL DEFAULT 0,
      originalPrice REAL,
      costPrice REAL,
      stock INTEGER DEFAULT 0,
      supplierId TEXT,
      category TEXT,
      image TEXT,
      craft TEXT,
      craftEn TEXT,
      material TEXT,
      origin TEXT,
      rating REAL DEFAULT 0,
      reviewCount INTEGER DEFAULT 0,
      featured INTEGER DEFAULT 0,
      active INTEGER DEFAULT 1,
      sortOrder INTEGER DEFAULT 0,
      createdAt TEXT DEFAULT (datetime('now')),
      updatedAt TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (supplierId) REFERENCES suppliers(id) ON DELETE SET NULL
    );

    -- 商品标签 (多对多)
    CREATE TABLE IF NOT EXISTS product_tags (
      productId TEXT NOT NULL,
      tag TEXT NOT NULL,
      lang TEXT NOT NULL DEFAULT 'zh',
      sortOrder INTEGER DEFAULT 0,
      PRIMARY KEY (productId, tag, lang),
      FOREIGN KEY (productId) REFERENCES products(id) ON DELETE CASCADE
    );

    -- 商品详情图
    CREATE TABLE IF NOT EXISTS product_images (
      productId TEXT NOT NULL,
      imageUrl TEXT NOT NULL,
      sortOrder INTEGER DEFAULT 0,
      PRIMARY KEY (productId, imageUrl),
      FOREIGN KEY (productId) REFERENCES products(id) ON DELETE CASCADE
    );

    -- 赠品绑定表（买一送一 / 免费搭配）
    -- 语义：购买 productId 时，可以把 giftProductId 作为赠品免费拿走。
    -- 每行一个可赠商品，quantity 表示一份主商品送几件。
    -- 一个主商品绑多个赠品时，前台让客户自己选一个（参考站的 "Choose your free gift"）。
    CREATE TABLE IF NOT EXISTS product_gifts (
      productId TEXT NOT NULL,
      giftProductId TEXT NOT NULL,
      quantity INTEGER NOT NULL DEFAULT 1,
      sortOrder INTEGER DEFAULT 0,
      PRIMARY KEY (productId, giftProductId),
      FOREIGN KEY (productId) REFERENCES products(id) ON DELETE CASCADE
    );

    -- 商品规格 / 款式表（variants）
    -- 语义：一个商品可以有多个款式/型号，每个款式对应自己的图片和价格。
    --   optionName  规格维度名，如 "Style" / "Color"（空则前台不显示标签）
    --   label       该规格的值，如 "Zen Black" / "Soft Ivory White"
    --   price       该款式价格（NULL = 用主商品价格）
    --   image       该款式主图（NULL = 用主商品图）
    --   stock       该款式库存（NULL = 用主商品库存）
    --   valueCode   可选的外部编码（对应供应商货号 / SKU），便于对账
    -- 前台：选不同款式 → 图片与价格联动切换
    CREATE TABLE IF NOT EXISTS product_variants (
      id TEXT PRIMARY KEY,
      productId TEXT NOT NULL,
      optionName TEXT DEFAULT '',
      label TEXT NOT NULL,
      valueCode TEXT DEFAULT '',
      price REAL,
      image TEXT,
      stock INTEGER,
      sortOrder INTEGER DEFAULT 0,
      active INTEGER NOT NULL DEFAULT 1,
      FOREIGN KEY (productId) REFERENCES products(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_product_variants_product ON product_variants(productId, sortOrder);

    -- 配套商品 / 搭配购买表（bundle，"Frequently bought together"）
    -- 语义：买 productId 时，可以一起加购 bundleProductId，组合成一个套餐价。
    --   title       搭配标题，如 "Add a matching tray"（前台搭配区块的小标题）
    --   description 搭配说明（为什么推荐一起买）
    --   image       搭配展示图；NULL = 用被搭配商品自己的主图
    --   price       搭配价（该商品在套餐里的价格）；NULL = 用该商品原价
    --   discount    组合优惠金额（一起买能省多少）
    -- 前台：商品页右侧「Frequently bought together」区块，
    --       勾选搭配商品后实时算出 单品价 / 优惠 / 总价。
    CREATE TABLE IF NOT EXISTS product_bundles (
      productId TEXT NOT NULL,
      bundleProductId TEXT NOT NULL,
      title TEXT DEFAULT '',
      description TEXT DEFAULT '',
      image TEXT,
      price REAL,
      discount REAL NOT NULL DEFAULT 0,
      sortOrder INTEGER DEFAULT 0,
      PRIMARY KEY (productId, bundleProductId),
      FOREIGN KEY (productId) REFERENCES products(id) ON DELETE CASCADE
    );

    -- 用户表
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      passwordHash TEXT NOT NULL,
      salt TEXT NOT NULL,
      firstName TEXT,
      lastName TEXT,
      phone TEXT,
      avatar TEXT,
      dob TEXT,
      gender TEXT,
      bio TEXT,
      preferredCurrency TEXT DEFAULT 'USD',
      role TEXT DEFAULT 'customer',
      token TEXT,
      tokenExpiresAt TEXT,
      createdAt TEXT DEFAULT (datetime('now')),
      updatedAt TEXT DEFAULT (datetime('now'))
    );

    -- 用户地址
    CREATE TABLE IF NOT EXISTS user_addresses (
      id TEXT PRIMARY KEY,
      userId TEXT NOT NULL,
      label TEXT,
      firstName TEXT,
      lastName TEXT,
      phone TEXT,
      address TEXT,
      city TEXT,
      state TEXT,
      zip TEXT,
      country TEXT DEFAULT 'United States',
      isDefault INTEGER DEFAULT 0,
      createdAt TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
    );

    -- 心愿单
    CREATE TABLE IF NOT EXISTS wishlist (
      userId TEXT NOT NULL,
      productId TEXT NOT NULL,
      createdAt TEXT DEFAULT (datetime('now')),
      PRIMARY KEY (userId, productId),
      FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (productId) REFERENCES products(id) ON DELETE CASCADE
    );

    -- 订单表
    CREATE TABLE IF NOT EXISTS orders (
      id TEXT PRIMARY KEY,
      orderNo TEXT UNIQUE NOT NULL,
      userId TEXT,
      status TEXT DEFAULT 'pending',
      totalAmount REAL NOT NULL DEFAULT 0,
      currency TEXT DEFAULT 'USD',
      subtotal REAL DEFAULT 0,
      shipping REAL DEFAULT 0,
      tax REAL DEFAULT 0,
      discount REAL DEFAULT 0,
      couponCode TEXT,
      customerName TEXT,
      customerEmail TEXT,
      customerPhone TEXT,
      shippingName TEXT,
      shippingAddress TEXT,
      shippingCity TEXT,
      shippingState TEXT,
      shippingZip TEXT,
      shippingCountry TEXT,
      billingName TEXT,
      billingAddress TEXT,
      billingCity TEXT,
      billingState TEXT,
      billingZip TEXT,
      billingCountry TEXT,
      shippingMethod TEXT,
      trackingNumber TEXT,
      carrier TEXT,
      paymentMethod TEXT,
      paymentStatus TEXT DEFAULT 'unpaid',
      referralCode TEXT,
      referralId TEXT,
      referralVisitorId TEXT,
      referredByStaffId TEXT,
      referredByStaffName TEXT,
      attributionClickId TEXT,
      attributionModel TEXT,
      attributionTouchpoints INTEGER,
      attributionLookbackDays INTEGER,
      attributionMatchedBy TEXT,
      attributionFallbackUsed INTEGER DEFAULT 0,
      paymentStatus TEXT DEFAULT 'unpaid',
      paypalTransaction TEXT,
      payoneerTransaction TEXT,
      returnInfo TEXT,
      notes TEXT,
      createdAt TEXT DEFAULT (datetime('now')),
      updatedAt TEXT DEFAULT (datetime('now'))
    );

    -- 订单商品
    CREATE TABLE IF NOT EXISTS order_items (
      id TEXT PRIMARY KEY,
      orderId TEXT NOT NULL,
      productId TEXT,
      name TEXT,
      nameEn TEXT,
      image TEXT,
      price REAL DEFAULT 0,
      quantity INTEGER DEFAULT 1,
      subtotal REAL DEFAULT 0,
      category TEXT,
      FOREIGN KEY (orderId) REFERENCES orders(id) ON DELETE CASCADE
    );

    -- 订单状态历史
    CREATE TABLE IF NOT EXISTS order_status_history (
      id TEXT PRIMARY KEY,
      orderId TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      note TEXT,
      timestamp TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (orderId) REFERENCES orders(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_order_status_history_orderId ON order_status_history(orderId);

    -- 评论表
    CREATE TABLE IF NOT EXISTS reviews (
      id TEXT PRIMARY KEY,
      productId TEXT NOT NULL,
      author TEXT DEFAULT 'Anonymous',
      avatar TEXT,
      rating INTEGER NOT NULL DEFAULT 5,
      date TEXT,
      content TEXT,
      location TEXT,
      approved INTEGER DEFAULT 0,
      createdAt TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (productId) REFERENCES products(id) ON DELETE CASCADE
    );

    -- 消息/联系表单
    CREATE TABLE IF NOT EXISTS messages (
      id TEXT PRIMARY KEY,
      name TEXT,
      email TEXT,
      phone TEXT,
      subject TEXT,
      message TEXT,
      status TEXT DEFAULT 'unread',
      createdAt TEXT DEFAULT (datetime('now')),
      source TEXT,
      attachments TEXT,
      adminReply TEXT,
      adminAttachments TEXT,
      adminName TEXT,
      adminAvatar TEXT,
      repliedAt TEXT,
      read INTEGER DEFAULT 0,
      replied INTEGER DEFAULT 0,
      senderType TEXT DEFAULT 'customer',
      chatType TEXT,
      fromStaffId TEXT,
      toStaffId TEXT,
      fromAvatar TEXT,
      fromName TEXT,
      toAvatar TEXT,
      toName TEXT,
      orderRef TEXT
    );

    -- 工作日志
    CREATE TABLE IF NOT EXISTS work_logs (
      id TEXT PRIMARY KEY,
      timestamp TEXT DEFAULT (datetime('now')),
      operatorId TEXT,
      operatorName TEXT,
      operatorRole TEXT,
      action TEXT,
      details TEXT,
      orderId TEXT,
      productId TEXT,
      category TEXT
    );

    -- Newsletter 订阅
    CREATE TABLE IF NOT EXISTS newsletter_subscribers (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      status TEXT DEFAULT 'active',
      createdAt TEXT DEFAULT (datetime('now'))
    );

    -- 网站设置 (单例, key-value)
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT,
      updatedAt TEXT DEFAULT (datetime('now'))
    );

    -- 员工表
    CREATE TABLE IF NOT EXISTS staff (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      passwordHash TEXT NOT NULL,
      salt TEXT NOT NULL,
      name TEXT,
      role TEXT DEFAULT 'editor',
      avatar TEXT,
      status TEXT DEFAULT 'active',
      createdAt TEXT DEFAULT (datetime('now')),
      updatedAt TEXT DEFAULT (datetime('now'))
    );

    -- Web Vitals 监控数据
    CREATE TABLE IF NOT EXISTS web_vitals (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      value REAL,
      rating TEXT,
      page TEXT,
      navigationType TEXT,
      createdAt TEXT DEFAULT (datetime('now'))
    );

    -- 浏览记录表
    CREATE TABLE IF NOT EXISTS browsing_history (
      id TEXT PRIMARY KEY,
      sessionId TEXT NOT NULL,
      userId TEXT,
      email TEXT,
      visitorId TEXT NOT NULL,
      productId TEXT NOT NULL,
      productName TEXT,
      productImage TEXT,
      productPrice REAL,
      productCode TEXT,
      productCategory TEXT,
      pageType TEXT DEFAULT 'product',
      duration INTEGER DEFAULT 0,
      ip TEXT,
      timestamp TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (productId) REFERENCES products(id) ON DELETE CASCADE
    );

    -- 物流发货记录表
    CREATE TABLE IF NOT EXISTS shipments (
      id TEXT PRIMARY KEY,
      orderId TEXT NOT NULL,
      orderNo TEXT,
      shipmentNo TEXT NOT NULL,
      carrierCode TEXT NOT NULL,
      carrierName TEXT,
      trackingNumber TEXT NOT NULL,
      status TEXT DEFAULT 'pending',
      weight REAL,
      shippingCost REAL,
      shippedAt TEXT,
      estimatedDelivery TEXT,
      deliveredAt TEXT,
      events TEXT,
      notes TEXT,
      createdBy TEXT,
      createdAt TEXT DEFAULT (datetime('now')),
      updatedAt TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (orderId) REFERENCES orders(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_shipments_orderId ON shipments(orderId);
    CREATE INDEX IF NOT EXISTS idx_shipments_trackingNumber ON shipments(trackingNumber);
    CREATE INDEX IF NOT EXISTS idx_shipments_status ON shipments(status);

    -- 客户记录表（客户留样）
    CREATE TABLE IF NOT EXISTS customers (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      firstName TEXT,
      lastName TEXT,
      phone TEXT,
      avatar TEXT,
      rating INTEGER DEFAULT 0,
      tier TEXT DEFAULT 'standard',
      notes TEXT,
      preferences TEXT,
      tags TEXT,
      totalOrders INTEGER DEFAULT 0,
      totalSpent REAL DEFAULT 0,
      lastOrderAt TEXT,
      createdAt TEXT DEFAULT (datetime('now')),
      updatedAt TEXT DEFAULT (datetime('now'))
    );

    -- 创建索引
    CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
    CREATE INDEX IF NOT EXISTS idx_products_active ON products(active);
    CREATE INDEX IF NOT EXISTS idx_products_featured ON products(featured);
    CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
    CREATE INDEX IF NOT EXISTS idx_orders_userId ON orders(userId);
    CREATE INDEX IF NOT EXISTS idx_reviews_productId ON reviews(productId);
    CREATE INDEX IF NOT EXISTS idx_wishlist_userId ON wishlist(userId);
    CREATE INDEX IF NOT EXISTS idx_order_items_orderId ON order_items(orderId);
    CREATE INDEX IF NOT EXISTS idx_messages_status ON messages(status);
    CREATE INDEX IF NOT EXISTS idx_browsing_sessionId ON browsing_history(sessionId);
    CREATE INDEX IF NOT EXISTS idx_browsing_email ON browsing_history(email);
    CREATE INDEX IF NOT EXISTS idx_browsing_productId ON browsing_history(productId);
    CREATE INDEX IF NOT EXISTS idx_customers_email ON customers(email);
    CREATE INDEX IF NOT EXISTS idx_customers_tier ON customers(tier);
  `);let t=new Set(e.prepare("PRAGMA table_info(orders)").all().map(e=>e.name)),a=(r,a)=>{if(!t.has(r))try{e.exec(`ALTER TABLE orders ADD COLUMN ${r} ${a}`)}catch{}};a("assignedTo","TEXT"),a("assignedToName","TEXT"),a("userEmail","TEXT"),a("estimatedDeliveryDays","INTEGER DEFAULT 0"),a("trackingUrl","TEXT"),a("estimatedDelivery","TEXT"),a("assignedToAvatar","TEXT"),a("referralCode","TEXT"),a("referralId","TEXT"),a("referralVisitorId","TEXT"),a("referredByStaffId","TEXT"),a("referredByStaffName","TEXT"),a("attributionClickId","TEXT"),a("attributionModel","TEXT"),a("attributionTouchpoints","INTEGER"),a("attributionLookbackDays","INTEGER"),a("attributionMatchedBy","TEXT"),a("attributionFallbackUsed","INTEGER DEFAULT 0"),a("paymentStatus","TEXT DEFAULT 'unpaid'"),a("paypalTransaction","TEXT"),a("payoneerTransaction","TEXT"),a("returnInfo","TEXT");let i=new Set(e.prepare("PRAGMA table_info(messages)").all().map(e=>e.name)),s=(t,r)=>{if(!i.has(t))try{e.exec(`ALTER TABLE messages ADD COLUMN ${t} ${r}`)}catch{}};s("source","TEXT"),s("attachments","TEXT"),s("adminReply","TEXT"),s("adminAttachments","TEXT"),s("adminName","TEXT"),s("adminAvatar","TEXT"),s("repliedAt","TEXT"),s("read","INTEGER DEFAULT 0"),s("replied","INTEGER DEFAULT 0"),s("senderType","TEXT DEFAULT 'customer'"),s("adminRead","INTEGER DEFAULT 0"),s("avatar","TEXT"),s("chatType","TEXT"),s("fromStaffId","TEXT"),s("toStaffId","TEXT"),s("fromAvatar","TEXT"),s("fromName","TEXT"),s("toAvatar","TEXT"),s("toName","TEXT"),s("orderRef","TEXT");let o=new Set(e.prepare("PRAGMA table_info(shipments)").all().map(e=>e.name)),n=(t,r)=>{if(!o.has(t))try{e.exec(`ALTER TABLE shipments ADD COLUMN ${t} ${r}`)}catch{}};n("notifiedAt","TEXT"),n("notifiedChannel","TEXT"),n("notifiedTo","TEXT");let d=new Set(e.prepare("PRAGMA table_info(reviews)").all().map(e=>e.name)),l=(t,r)=>{if(!d.has(t))try{e.exec(`ALTER TABLE reviews ADD COLUMN ${t} ${r}`)}catch{}};l("orderId","TEXT"),l("customerEmail","TEXT"),l("hidden","INTEGER DEFAULT 0"),l("deleted","INTEGER DEFAULT 0"),l("source","TEXT DEFAULT 'customer'");let u=new Set(e.prepare("PRAGMA table_info(products)").all().map(e=>e.name)),p=(t,r)=>{if(!u.has(t))try{e.exec(`ALTER TABLE products ADD COLUMN ${t} ${r}`)}catch{}};if(p("costPrice","REAL"),p("stock","INTEGER DEFAULT 0"),p("supplierId","TEXT"),p("code","TEXT"),p("video","TEXT"),p("videoEnabled","INTEGER DEFAULT 0"),p("listingVisible","INTEGER DEFAULT 1"),!new Set(e.prepare("PRAGMA table_info(users)").all().map(e=>e.name)).has("coupons"))try{e.exec("ALTER TABLE users ADD COLUMN coupons TEXT")}catch{}try{let{generateProductCode:t}=r(62545),a=e.prepare("SELECT id, category FROM products WHERE code IS NULL OR code = '' ORDER BY createdAt ASC").all();if(a.length>0){let r=new Set(e.prepare("SELECT code FROM products WHERE code IS NOT NULL AND code != ''").all().map(e=>e.code));for(let i of a){let a=t(i.category||"",r);e.prepare("UPDATE products SET code = ? WHERE id = ?").run(a,i.id),r.add(a)}}}catch{}e.exec(`
    CREATE TABLE IF NOT EXISTS suppliers (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      contact TEXT,
      phone TEXT,
      email TEXT,
      address TEXT,
      region TEXT,
      status TEXT DEFAULT 'active',
      notes TEXT,
      createdAt TEXT DEFAULT (datetime('now')),
      updatedAt TEXT DEFAULT (datetime('now'))
    )
  `);let E=new Set(e.prepare("PRAGMA table_info(browsing_history)").all().map(e=>e.name));if(!E.has("ip"))try{e.exec("ALTER TABLE browsing_history ADD COLUMN ip TEXT")}catch{}if(!E.has("productCode"))try{e.exec("ALTER TABLE browsing_history ADD COLUMN productCode TEXT")}catch{}try{e.exec(`
      DELETE FROM browsing_history
      WHERE id NOT IN (
        SELECT id FROM (
          SELECT id,
            ROW_NUMBER() OVER (
              PARTITION BY visitorId, productId
              ORDER BY timestamp DESC
            ) AS rn
          FROM browsing_history
          WHERE EXISTS (
            SELECT 1 FROM browsing_history b2
            WHERE b2.visitorId = browsing_history.visitorId
              AND b2.productId = browsing_history.productId
              AND ABS(strftime('%s', b2.timestamp) - strftime('%s', browsing_history.timestamp)) < 30
          )
        ) WHERE rn = 1
      )
      AND EXISTS (
        SELECT 1 FROM browsing_history b3
        WHERE b3.visitorId = browsing_history.visitorId
          AND b3.productId = browsing_history.productId
          AND b3.id != browsing_history.id
          AND ABS(strftime('%s', b3.timestamp) - strftime('%s', browsing_history.timestamp)) < 30
      )
    `)}catch{}return e}},35102:(e,t,r)=>{r.r(t),r.d(t,{addOrder:()=>g,assignOrderToStaff:()=>A,getAllOrders:()=>u,getOrderById:()=>E,getOrderStats:()=>S,getOrdersByStaffId:()=>p,getOrdersByUserEmail:()=>m,getRecentOrders:()=>T,getRevenueDaily:()=>c,updateOrder:()=>f,updateOrderNotes:()=>I,updateOrderStatus:()=>h,updateOrderTracking:()=>y});var a=r(29021),i=r.n(a),s=r(33873),o=r.n(s),n=r(51105);let d=o().join(process.cwd(),"data"),l=o().join(d,"orders.json");function u(){return i().existsSync(d)||i().mkdirSync(d,{recursive:!0}),i().existsSync(l)||i().writeFileSync(l,"[]","utf-8"),(0,n.hi)("orders",l,()=>JSON.parse(i().readFileSync(l,"utf-8").replace(/^\uFEFF/,"").trim()),n.U_.orders)}function p(e){return u().filter(t=>t.assignedTo===e)}function c(e=7){let t=u().filter(e=>"cancelled"!==e.status),r=[];for(let a=e-1;a>=0;a--){let e=new Date(Date.now()-864e5*a).toISOString().split("T")[0],i=t.filter(t=>t.createdAt.startsWith(e));r.push({date:e,revenue:i.reduce((e,t)=>e+t.total,0),count:i.length})}return r}function E(e){return u().find(t=>t.id===e)}function m(e){return u().filter(t=>t.userEmail===e||t.customerEmail===e||t.shipping?.email===e)}function T(e=7){let t=Date.now()-864e5*e;return u().filter(e=>new Date(e.createdAt).getTime()>t)}function g(e){let t=u(),r={...e,statusHistory:[{status:"pending",timestamp:new Date().toISOString(),note:"Order placed"}]};return t.unshift(r),i().writeFileSync(l,JSON.stringify(t,null,2),"utf-8"),(0,n.gm)("orders"),r}function f(e,t){let r=u(),a=r.findIndex(t=>t.id===e);return -1===a?null:(r[a]={...r[a],...t},i().writeFileSync(l,JSON.stringify(r,null,2),"utf-8"),(0,n.gm)("orders"),r[a])}function h(e,t,r,a){let s=u(),o=s.findIndex(t=>t.id===e);return -1===o?null:(s[o]={...s[o],status:t,tracking:a||s[o].tracking,statusHistory:[...s[o].statusHistory||[],{status:t,timestamp:new Date().toISOString(),note:r||({pending:"Order placed",confirmed:"Order confirmed, preparing for shipment",processing:"Order is being processed",shipped:"Package shipped",delivered:"Package delivered",cancelled:"Order cancelled",return_requested:"Return requested",return_approved:"Return approved",return_shipped:"Return shipped",return_delivered:"Return delivered",refunded:"Refund processed"})[t]||"Status updated"}]},i().writeFileSync(l,JSON.stringify(s,null,2),"utf-8"),(0,n.gm)("orders"),s[o])}function y(e,t){let r=u(),a=r.findIndex(t=>t.id===e);return -1===a?null:(r[a]={...r[a],tracking:t},("processing"===r[a].status||"confirmed"===r[a].status)&&(r[a].status="shipped",r[a].statusHistory=[...r[a].statusHistory||[],{status:"shipped",timestamp:new Date().toISOString(),note:"Package shipped with "+t.carrier}]),i().writeFileSync(l,JSON.stringify(r,null,2),"utf-8"),(0,n.gm)("orders"),r[a])}function I(e,t){let r=u(),a=r.findIndex(t=>t.id===e);return -1===a?null:(r[a]={...r[a],notes:t},i().writeFileSync(l,JSON.stringify(r,null,2),"utf-8"),(0,n.gm)("orders"),r[a])}function S(){let e=u();return{total:e.length,pending:e.filter(e=>"pending"===e.status).length,confirmed:e.filter(e=>"confirmed"===e.status).length,processing:e.filter(e=>"processing"===e.status).length,shipped:e.filter(e=>"shipped"===e.status).length,delivered:e.filter(e=>"delivered"===e.status).length,cancelled:e.filter(e=>"cancelled"===e.status).length,revenue:e.reduce((e,t)=>e+("cancelled"!==t.status?t.total:0),0)}}function A(e,t,r,a){let s=u(),o=s.findIndex(t=>t.id===e);return -1===o?null:(s[o]={...s[o],assignedTo:t,assignedToName:r,assignedToAvatar:a,statusHistory:[...s[o].statusHistory||[],{status:s[o].status,timestamp:new Date().toISOString(),note:"Assigned to "+r}]},i().writeFileSync(l,JSON.stringify(s,null,2),"utf-8"),(0,n.gm)("orders"),s[o])}},20351:(e,t,r)=>{r.d(t,{TM:()=>n,yF:()=>s});let a=null,i=null;function s(){return"sqlite"===(process.env.DATABASE_BACKEND||"json")?"sqlite":"json"}let o=null;function n(){return o||(o="sqlite"===s()?function(){if(i)return i;let{productRepo:e,supplierRepo:t,reviewRepo:a,orderRepo:s,userRepo:o,categoryRepo:n,messageRepo:d,settingsRepo:l,staffRepo:u,newsletterRepo:p,workLogRepo:c,browsingHistoryRepo:E,customerRepo:m,shipmentRepo:T}=r(2885);return i={products:e,suppliers:t,reviews:a,orders:s,users:o,categories:n,messages:d,settings:l,staff:u,newsletter:p,workLogs:c,browsingHistory:E,customers:m,shipments:T}}():function(){if(a)return a;let{getAllProducts:e,getProductById:t,getProductsByCategory:i,addProduct:s,updateProduct:o,deleteProduct:n}=r(62545),{getAllReviews:d,getReviewsByProduct:l,addReview:u,updateReview:p}=r(62545),{getAllOrders:c,getOrderById:E,addOrder:m,updateOrder:T}=r(35102),{getAllUsers:g,findUserById:f,findUserByEmail:h,addUser:y,updateUser:I}=r(22831),{getAllCategories:S,getCategoryBySlug:A,addCategory:N,updateCategory:b,deleteCategory:v}=r(63783),{getSettings:L,saveSettings:R}=r(68818),{getAllLogs:O,addLog:C}=r(60221),D=r(29021),w=r(33873),U=w.join(process.cwd(),"data"),X=w.join(U,"messages.json"),F=w.join(U,"newsletter.json");function k(){try{if(D.existsSync(X)){let e=D.readFileSync(X,"utf-8").replace(/^\uFEFF/,"").trim();return JSON.parse(e)||[]}}catch{}return[]}function M(e){D.existsSync(U)||D.mkdirSync(U,{recursive:!0}),D.writeFileSync(X,JSON.stringify(e,null,2),"utf-8")}function B(){try{if(D.existsSync(F)){let e=D.readFileSync(F,"utf-8").replace(/^\uFEFF/,"").trim();return(JSON.parse(e)||[]).map((e,t)=>({id:e.id||"NL-"+(t+1),email:e.email,status:e.status||"active",createdAt:e.subscribedAt||e.createdAt||new Date().toISOString(),subscribedAt:e.subscribedAt||e.createdAt||new Date().toISOString(),source:e.source||"footer"}))}}catch{}return[]}function P(e){D.existsSync(U)||D.mkdirSync(U,{recursive:!0}),D.writeFileSync(F,JSON.stringify(e.map(e=>({email:e.email,subscribedAt:e.subscribedAt||e.createdAt,source:e.source||"footer"})),null,2),"utf-8")}return a={products:{list:e,listActive:()=>e().filter(e=>!1!==e.active),getById:t,getByCategory:i,add:s,update:o,delete:n},suppliers:{list:()=>[],getById:()=>void 0,add:e=>e,update:()=>null,delete:()=>!1,getProductCount:()=>0},reviews:{list:d,getByProduct:l,add:u,update:p},orders:{list:c,getById:E,add:m,update:T},users:{list:g,getById:f,getByEmail:h,getByToken:e=>g().find(t=>t.token===e),add:y,update:I},categories:{list:S,getBySlug:A,add:e=>(N(e.slug,e),e),update:(e,t)=>(b(e,t),A(e)||null),delete:e=>{let t=S().length;return v(e),S().length<t}},messages:{list:k,getById:e=>k().find(t=>t.id===e),add:e=>{let t=k(),r={...e,id:e.id||"MSG-"+Date.now().toString(36).toUpperCase(),createdAt:e.createdAt||new Date().toISOString(),read:void 0!==e.read&&e.read,replied:void 0!==e.replied&&e.replied,name:e.name||"",email:e.email||"",message:e.message||"",senderType:e.senderType||"customer",chatType:e.chatType||void 0,fromStaffId:e.fromStaffId||void 0,toStaffId:e.toStaffId||void 0,fromAvatar:e.fromAvatar||void 0,fromName:e.fromName||void 0,toAvatar:e.toAvatar||void 0,toName:e.toName||void 0,orderRef:e.orderRef||void 0};return t.unshift(r),M(t),r},update:(e,t)=>{let r=k(),a=r.findIndex(t=>t.id===e);return -1===a?null:(r[a]={...r[a],...t},M(r),r[a])}},settings:{get:L,update:e=>R(e)},staff:{list:()=>L().staffMembers||[],getById:e=>(L().staffMembers||[]).find(t=>t.id===e),getByEmail:e=>(L().staffMembers||[]).find(t=>t.email.toLowerCase()===e.toLowerCase()),add:e=>{let t=L().staffMembers||[],r={...e,id:e.id||"STF-"+Date.now().toString(36).toUpperCase(),createdAt:e.createdAt||new Date().toISOString()};return t.push(r),R({staffMembers:t}),r},update:(e,t)=>{let r=L().staffMembers||[],a=r.findIndex(t=>t.id===e);return -1===a?null:(r[a]={...r[a],...t},R({staffMembers:r}),r[a])},delete:e=>{let t=L().staffMembers||[],r=t.length,a=t.filter(t=>t.id!==e);return a.length!==r&&(R({staffMembers:a}),!0)}},newsletter:{list:B,getByEmail:e=>B().find(t=>t.email.toLowerCase()===e.toLowerCase()),add:(e,t="footer")=>{let r=B(),a=e.toLowerCase().trim(),i=r.find(e=>e.email===a);if(i)return i;let s={id:"NL-"+Date.now().toString(36).toUpperCase(),email:a,status:"active",createdAt:new Date().toISOString(),subscribedAt:new Date().toISOString(),source:t};return r.push(s),P(r),s},delete:e=>{let t=B(),r=t.length,a=t.filter(t=>t.id!==e);return a.length!==r&&(P(a),!0)}},workLogs:{list:O,add:e=>C(e)},shipments:{list:()=>[],getByOrderId:()=>[],getByTrackingNumber:()=>null,getById:()=>null,add:e=>e,update:()=>null,addTrackEvent:()=>null,delete:()=>!1,getStats:()=>({total:0,inTransit:0,delivered:0,pending:0})},browsingHistory:{},customers:{}}}())}new Proxy({},{get:(e,t)=>n()[t]})},68818:(e,t,r)=>{r.r(t),r.d(t,{DEFAULTS:()=>c,calculateShipping:()=>N,getSettings:()=>f,getShippingZoneForCountry:()=>y,hashStaffPassword:()=>I,normalizeSavedSettings:()=>E,saveSettings:()=>h,verifyStaffPassword:()=>A});var a=r(29021),i=r.n(a),s=r(33873),o=r.n(s),n=r(55511),d=r.n(n),l=r(51105);let u=o().join(process.cwd(),"data"),p=o().join(u,"settings.json"),c={autoConfirmMinutes:0,autoAssignOrders:!1,autoAssignStrategy:"round_robin",autoAssignMode:"disabled",autoAssignTargetRole:"order_processor",autoAssignTargetStaff:"",glassLayered:!0,glassSidebar:!0,glassTopbar:!0,glassMenus:!0,glassLists:!0,staffMembers:[],adminUsername:"admin",adminEmail:"admin@lowflame.com",adminAvatar:"",adminPhone:"",adminBio:"",adminPassword:"",adminPasswordHash:"",adminPasswordSalt:"",siteName:"Low Flame",siteTagline:"",siteUrl:"",siteLogo:"",heroTitle:"Artisanal Treasures",heroSubtitle:"Hand-selected ceramics, silk, bamboo, and paper-cut art from master craftspeople across China.",heroBackgroundImage:"https://images.unsplash.com/photo-1508804185872-d7badad00f7d?w=1920&q=80",primaryColor:"#221E1A",accentColor:"#5F7D72",featuredProductIds:[],aboutText:"Low Flame — contemporary craftsmanship with quiet character.",footerEmail:"hello@lowflame.store",footerPhone:"+86 183 3734 0646",currency:"USD",shippingFreeThreshold:416.67,cnyUsdRate:7.2,shippingCost:34.72,smtpHost:"",smtpPort:587,smtpUser:"",smtpPass:"",smtpFromEmail:"",smtpReplyTo:"",socialFacebook:"https://facebook.com",socialX:"https://x.com",socialInstagram:"https://instagram.com",socialYoutube:"https://youtube.com",footerHours:"Mon-Sat 9:00-18:00 (CST)",footerAddress:"",footerCopyright:"All rights reserved.",footerPrivacyLink:"/privacy",footerTermsLink:"/terms",defaultShippingDays:14,shippingZones:[{id:"us-canada",name:"United States & Canada",countries:["United States","Canada"],baseCost:34.72,freeThreshold:416.67,estimatedDaysMin:7,estimatedDaysMax:14,carriers:["UPS","FedEx","USPS"]},{id:"europe",name:"Europe",countries:["United Kingdom","Germany","France","Italy","Spain","Netherlands","Other"],baseCost:48.61,freeThreshold:555.56,estimatedDaysMin:10,estimatedDaysMax:18,carriers:["DHL","FedEx","UPS"]},{id:"asia-pacific",name:"Asia Pacific",countries:["Australia","Japan","South Korea","Singapore"],baseCost:41.67,freeThreshold:486.11,estimatedDaysMin:8,estimatedDaysMax:15,carriers:["DHL","EMS","FedEx"]},{id:"rest-of-world",name:"Rest of World",countries:["Other"],baseCost:55.56,freeThreshold:694.44,estimatedDaysMin:12,estimatedDaysMax:21,carriers:["DHL","EMS"]}],defaultCarrier:"DHL",trackingUrlTemplate:"https://www.dhl.com/cn/en/tracking.html?tracking-id={tracking}",paypalEnabled:!1,paypalEnv:"sandbox",paypalClientId:"",paypalClientSecret:"",paypalWebhookId:"",payoneerEnabled:!1,payoneerEnv:"sandbox",payoneerClientId:"",payoneerClientSecret:"",frontendContent:{hero:{eyebrow:"Low Flame \xb7 Contemporary Craftsmanship",headline:"Objects That\nCarry Stories",headlineAccent:"Carry Stories",subtitle:"Celadon, silk, bamboo, and incense — each piece hand-selected from master craftspeople who have spent a lifetime perfecting their art.",buttonText:"Explore the Collection",buttonLink:"/products",secondaryText:"Our Philosophy",secondaryLink:"/#philosophy",backgroundImage:"https://images.unsplash.com/photo-1508804185872-d7badad00f7d?w=1920&q=80",overlayOpacity:55},philosophyStrip:[{number:"01",label:"Hand-Selected",desc:"Every object personally curated from master workshops"},{number:"02",label:"Authentic Craft",desc:"Direct from artisans preserving centuries-old techniques"},{number:"03",label:"Ethical Sourcing",desc:"Fair partnerships supporting traditional communities"},{number:"04",label:"Timeless Design",desc:"Objects made to last, designed to be cherished"}],collections:[{title:"Tea Ceremony",subtitle:"The Art of Cha Dao",slug:"cultural-gifts",image:"https://images.unsplash.com/photo-1515377905703-c4788e51af15?w=1200&q=80",description:"Hand-thrown celadon and Yixing teaware that transforms tea brewing into a meditative ritual."},{title:"Ceramic Living",subtitle:"Daily Vessels, Timeless Beauty",slug:"home-decor",image:"https://images.unsplash.com/photo-1586105251261-72a756497a11?w=1200&q=80",description:"Porcelain and stoneware made for everyday use, each shaped by centuries of tradition."},{title:"Silk & Embroidery",subtitle:"Threads of Heritage",slug:"cultural-gifts",image:"https://images.unsplash.com/photo-1607532941432-5e0d3cba768b?w=1200&q=80",description:"Suzhou double-sided embroidery preserving an endangered craft."},{title:"Bamboo Craft",subtitle:"Sustainable Artistry",slug:"home-decor",image:"https://images.unsplash.com/photo-1513519245088-0e12902e35ca?w=1200&q=80",description:"Baskets and objects woven by master artisans in Zhejiang."},{title:"Natural Incense",subtitle:"Sacred Scents",slug:"creative-gifts",image:"https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=1200&q=80",description:"Agarwood, sandalwood, and herbal blends using ancient formulas."},{title:"Scholar's Desk",subtitle:"The Art of Writing",slug:"creative-gifts",image:"https://images.unsplash.com/photo-1496096265110-f83ad7f96608?w=1200&q=80",description:"Brush pots, ink stones, and writing sets for the modern scholar."}],collectionsSlideshowEnabled:!0,collectionsSlideshowInterval:6,featuredSection:{eyebrow:"Curated Selection",headline:"Featured Pieces"},artisanStory:{image:"https://images.unsplash.com/photo-1508804185872-d7badad00f7d?w=800&q=80",badgeNumber:"45+",badgeText:"Master artisans in our network",eyebrow:"Behind the Craft",headline:"Every Object Has a\nMaker, Place, Story",headlineAccent:"Maker, Place, Story",paragraph1:"We travel to remote villages — not to source products, but to find the people who keep living traditions alive.",paragraph2:"Each piece is accompanied by the name of the artisan, their workshop, and the story behind the technique.",buttonText:"Meet the Artisans",buttonLink:"/products"},philosophySection:{eyebrow:"Our Philosophy",headline:"Beauty Lives in the\nDetails We Often Overlook",headlineAccent:"Details We Often Overlook",body:"We believe everyday objects carry cultural memory, emotional weight, and quiet beauty. In a world of mass production, choosing handmade is a connection to something larger than ourselves.",quotes:[{quote:"The potter shapes not just clay, but the stillness of the person who will drink from it.",author:"— Master Wei, Celadon Artisan"},{quote:"A single silk thread can carry a thousand years of culture.",author:"— Chen Li, Embroidery Artist"},{quote:"We do not create beauty. We simply remove everything that is not essential.",author:"— Zen saying"}]},journal:{eyebrow:"Stories & Essays",headline:"The Journal",body:"Explorations of craft, culture, and the philosophy of everyday objects.",entries:[{image:"https://images.unsplash.com/photo-1515377905703-c4788e51af15?w=800&q=80",date:"June 2026",readTime:"8",title:"The Celadon Tradition",excerpt:"How a single glaze color became one of China's most cherished artistic legacies.",link:"/#journal"},{image:"https://images.unsplash.com/photo-1607532941432-5e0d3cba768b?w=800&q=80",date:"May 2026",readTime:"6",title:"Inside the Workshop: Suzhou Embroidery",excerpt:"A rare glimpse into the studio where silk threads become paintings.",link:"/#journal"},{image:"https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=800&q=80",date:"April 2026",readTime:"10",title:"The Way of Tea",excerpt:"Beyond ceremony, tea culture offers a philosophy of presence and simplicity.",link:"/#journal"}]},seasonal:{eyebrow:"Seasonal Edition",headline:"Summer Collection",body:"Light bamboo fans, summer-weight silk, celadon tea sets for warm afternoons, and incense blended for the season of long, slow days.",buttonText:"Explore Summer Collection",buttonLink:"/products",secondaryText:"Request a Lookbook",secondaryLink:"/contact",backgroundImage:"https://images.unsplash.com/photo-1547981609-4b6bfe67ca0b?w=1920&q=80"},newsletter:{eyebrow:"Stay Connected",headline:"Receive Stories from the Studio",body:"Monthly dispatches on new collections, artisan interviews, and the philosophy of craft.",buttonText:"Subscribe",disclaimer:"No spam. Unsubscribe anytime."},footer:{brandDesc:"Low Flame — contemporary craftsmanship. Each piece connects you to the artisan who made it.",collections:[{label:"Tea Ceremony",href:"/products"},{label:"Ceramic Living",href:"/products"},{label:"Silk & Embroidery",href:"/products"},{label:"Bamboo Craft",href:"/products"},{label:"Natural Incense",href:"/products"},{label:"Scholar's Desk",href:"/products"}],companyLinks:[{label:"About",href:"/#philosophy"},{label:"Journal",href:"/#journal"},{label:"Contact",href:"/contact"},{label:"Shipping",href:"/shipping-policy"},{label:"Returns",href:"/refund-policy"}],contacts:[{label:"Email",value:"hello@lowflame.store"},{label:"Phone",value:"+86 183 3734 0646"},{label:"Hours",value:"Mon–Fri, 9:00 AM – 6:00 PM (EST)"}],socialLinks:[{label:"X",href:"https://x.com",color:"hover:text-white"},{label:"IG",href:"https://instagram.com",color:"hover:text-[#E4405F]"},{label:"FB",href:"https://facebook.com",color:"hover:text-[#1877F2]"},{label:"PT",href:"https://pinterest.com",color:"hover:text-[#E60023]"},{label:"YT",href:"https://youtube.com",color:"hover:text-[#FF0000]"}],bottomLinks:["Privacy","Terms","Cookie Policy"],copyright:"All rights reserved."}},customerTiers:[{id:"new",name:"New",minOrders:0,maxOrders:0,stars:1,color:"#3b82f6",bgColor:"#dbeafe"},{id:"bronze",name:"Bronze",minOrders:1,maxOrders:2,stars:2,color:"#b45309",bgColor:"#fef3c7"},{id:"silver",name:"Silver",minOrders:3,maxOrders:5,stars:3,color:"#6b7280",bgColor:"#F2EADF"},{id:"gold",name:"Gold",minOrders:6,maxOrders:10,stars:4,color:"#f59e0b",bgColor:"#fefce8"},{id:"vip",name:"VIP",minOrders:11,maxOrders:9999,stars:5,color:"#e11d48",bgColor:"#fef2f2"}],aiEnabled:!1,aiProvider:"openai",aiApiKey:"",aiLLMProviders:{deepseek:{apiKey:"",baseUrl:"https://api.deepseek.com/v1",models:[{id:"deepseek-chat",label:"DeepSeek V3 (deepseek-chat)"},{id:"deepseek-reasoner",label:"DeepSeek R1 (deepseek-reasoner)"}]},siliconflow:{apiKey:"",baseUrl:"https://api.siliconflow.cn/v1",models:[{id:"deepseek-ai/DeepSeek-V3",label:"DeepSeek V3"},{id:"deepseek-ai/DeepSeek-R1",label:"DeepSeek R1"},{id:"Qwen/Qwen3-32B",label:"Qwen3-32B"},{id:"zai-org/GLM-4.5",label:"GLM-4.5"}]},openai:{apiKey:"",baseUrl:"https://api.openai.com/v1",models:[{id:"gpt-4o-mini",label:"GPT-4o mini"},{id:"gpt-4o",label:"GPT-4o"},{id:"gpt-4.1-mini",label:"GPT-4.1 mini"}]},qwen:{apiKey:"",baseUrl:"https://dashscope.aliyuncs.com/compatible-mode/v1",models:[{id:"qwen-plus",label:"Qwen Plus"},{id:"qwen-max",label:"Qwen Max"},{id:"qwen-turbo",label:"Qwen Turbo"}]},zhipu:{apiKey:"",baseUrl:"https://open.bigmodel.cn/api/paas/v4",models:[{id:"glm-4-plus",label:"GLM-4 Plus"},{id:"glm-4-air",label:"GLM-4 Air"},{id:"glm-4-flash",label:"GLM-4 Flash"}]}},aiModel:"gpt-4o-mini",aiBaseUrl:"",aiSystemPrompt:"You are a helpful e-commerce assistant for Low Flame. You help analyze orders, customers, and business operations. Be concise and professional.",aiAssistantName:"Aria",aiPersonality:"",aiCopyProvider:"deepseek",aiCopyApiKey:"",aiCopyModel:"deepseek-chat",aiCopyBaseUrl:"",aiImageEnabled:!1,aiImageProvider:"siliconflow",aiImageApiKey:"",aiImageProviders:{siliconflow:{apiKey:"",baseUrl:"https://api.siliconflow.cn/v1",models:[{id:"Tongyi-MAI/Z-Image-Turbo",label:"Tongyi Z-Image Turbo（免费）"},{id:"Tongyi-MAI/Z-Image",label:"Tongyi Z-Image"},{id:"Kwai-Kolors/Kolors",label:"Kwai Kolors"},{id:"Qwen/Qwen-Image",label:"Qwen-Image"},{id:"BFL/FLUX.1-dev",label:"FLUX.1-dev"}]},minimax:{apiKey:"",baseUrl:"https://api.minimaxi.com/v1",models:[{id:"image-01",label:"image-01（文生图/参考图）"},{id:"image-01-live",label:"image-01-live"}]},ark:{apiKey:"",baseUrl:"https://ark.cn-beijing.volces.com/api/v3",models:[{id:"doubao-seedream-4-0-250828",label:"Seedream 4.0（1K/2K/4K）"},{id:"doubao-seedream-4-5-251128",label:"Seedream 4.5（2K/4K，细节更强）"},{id:"doubao-seedream-5-0-260128",label:"Seedream 5.0（2K/3K，旗舰）"}]},openai:{apiKey:"",baseUrl:"https://api.openai.com/v1",models:[{id:"gpt-image-1",label:"gpt-image-1（推荐）"},{id:"dall-e-3",label:"DALL\xb7E 3"}]}},aiImageModel:"Tongyi-MAI/Z-Image-Turbo",aiImageRefModel:"Tongyi-MAI/Z-Image",aiImageBaseUrl:"https://api.siliconflow.cn/v1",aiImageSize:"1024x1024",aiImageRefProvider:"",aiImageRefApiKey:"",aiImageRefBaseUrl:"",aiVideoEnabled:!1,aiVideoProvider:"ark",aiVideoApiKey:"",aiVideoModel:"doubao-seedance-2-0-260128",aiVideoBaseUrl:"",aiVideoProviders:{ark:{apiKey:"",baseUrl:"https://ark.cn-beijing.volces.com/api/v3",models:[{id:"doubao-seedance-2-0-260128",label:"Seedance 2.0（旗舰，图生视频/原生音频）"},{id:"doubao-seedance-2-0-fast-260128",label:"Seedance 2.0 Fast（快速）"},{id:"doubao-seedance-1-5-pro-251215",label:"Seedance 1.5 Pro（图生视频）"},{id:"doubao-seedance-1-0-pro-250528",label:"Seedance 1.0 Pro（图生视频）"},{id:"doubao-seedance-1-0-lite-i2v-250428",label:"Seedance 1.0 Lite i2v"}]},minimax:{apiKey:"",baseUrl:"https://api.minimaxi.com",models:[{id:"MiniMax-H3",label:"MiniMax H3（旗舰，图生/文生/多模态参考，原生音频）"},{id:"video-01",label:"Video-01（图生视频）"},{id:"video-01-live",label:"Video-01 Live"}]}},aiAudioProvider:"minimax",aiAudioApiKey:"",aiAudioModel:"music-3.0-free",aiAudioBaseUrl:"https://api.minimaxi.com",aiAudioProviders:{minimax:{apiKey:"",baseUrl:"https://api.minimaxi.com",models:[{id:"music-3.0-free",label:"Music 3.0 Free（纯音乐，免费额度）"},{id:"music-2.6-free",label:"Music 2.6 Free（纯音乐，免费额度）"},{id:"music-3.0",label:"Music 3.0（付费，效果最佳）"},{id:"speech-02-hd",label:"Speech 02 HD（高清配音）"},{id:"speech-02-turbo",label:"Speech 02 Turbo（快速配音）"}]}},xApiEnabled:!1,xApiKey:"",xApiSecret:"",xClientId:"",xClientSecret:"",xApiAuthType:"oauth2",xAccessToken:"",xAccessTokenSecret:"",xCallbackUrl:"",fbApiEnabled:!1,fbClientId:"",fbClientSecret:"",fbPageAccessToken:"",fbCallbackUrl:"",igApiEnabled:!1,igClientId:"",igClientSecret:"",igAccessToken:"",igCallbackUrl:"",igBusinessAccountId:"",igContentPublishEnabled:!1,igManageMessagesEnabled:!1,igManageCommentsEnabled:!1,igForceReauth:!1,igInsightsEnabled:!1,webhookVerifyToken:"",webhookIgSubscribed:!1,webhookFbSubscribed:!1,webhookXSubscribed:!1,webhookPtSubscribed:!1,webhookBaseUrl:"",metaAppSecret:"",attributionModel:"last_click",attributionLookbackDays:7,attributionRequireVisitorMatch:!0,attributionAllowReferralFallback:!0,liApiEnabled:!1,liClientId:"",liClientSecret:"",liAccessToken:"",liCallbackUrl:"",ytApiEnabled:!1,ytClientId:"",ytClientSecret:"",ytApiKey:"",ytAccessToken:"",ytCallbackUrl:"",ptApiEnabled:!1,ptClientId:"",ptClientSecret:"",ptAccessToken:"",ptCallbackUrl:"",tkApiEnabled:!1,tkClientId:"",tkClientSecret:"",tkAccessToken:"",tkCallbackUrl:""};function E(e){let t=JSON.parse(JSON.stringify(c.aiLLMProviders)),r=(e.aiCopyProvider||e.aiProvider||"deepseek").toLowerCase();if(!e.aiCopyApiKey||t[r]&&t[r].apiKey){if(e.aiApiKey&&(!t[e.aiProvider]||!t[e.aiProvider].apiKey)){let r=(e.aiProvider||"openai").toLowerCase();t[r]||(t[r]={apiKey:"",baseUrl:"",models:[]}),t[r].apiKey=e.aiApiKey,!t[r].baseUrl&&e.aiBaseUrl&&(t[r].baseUrl=e.aiBaseUrl)}}else t[r]||(t[r]={apiKey:"",baseUrl:"",models:[]}),t[r].apiKey=e.aiCopyApiKey,!t[r].baseUrl&&e.aiCopyBaseUrl&&(t[r].baseUrl=e.aiCopyBaseUrl);let a=JSON.parse(JSON.stringify(c.aiImageProviders)),i=(e.aiImageProvider||"siliconflow").toLowerCase();!e.aiImageApiKey||a[i]&&a[i].apiKey||(a[i]||(a[i]={apiKey:"",baseUrl:"",models:[]}),a[i].apiKey=e.aiImageApiKey,a[i].baseUrl||!e.aiImageBaseUrl||(a[i].baseUrl=e.aiImageBaseUrl));let s=(e.aiImageRefProvider||e.aiImageProvider||"siliconflow").toLowerCase();!e.aiImageRefApiKey||a[s]&&a[s].apiKey||(a[s]||(a[s]={apiKey:"",baseUrl:"",models:[]}),a[s].apiKey=e.aiImageRefApiKey,a[s].baseUrl||!e.aiImageRefBaseUrl||(a[s].baseUrl=e.aiImageRefBaseUrl));let o=JSON.parse(JSON.stringify(c.aiVideoProviders)),n=(e.aiVideoProvider||"ark").toLowerCase();!e.aiVideoApiKey||o[n]&&o[n].apiKey||(o[n]||(o[n]={apiKey:"",baseUrl:"",models:[]}),o[n].apiKey=e.aiVideoApiKey,o[n].baseUrl||!e.aiVideoBaseUrl||(o[n].baseUrl=e.aiVideoBaseUrl));let d=JSON.parse(JSON.stringify(c.aiAudioProviders)),l=(e.aiAudioProvider||"minimax").toLowerCase(),u=e.aiAudioApiKey||e.aiVideoProviders?.minimax?.apiKey||e.aiLLMProviders?.minimax?.apiKey||e.aiImageProviders?.minimax?.apiKey;return!u||d[l]&&d[l].apiKey||(d[l]||(d[l]={apiKey:"",baseUrl:"",models:[]}),d[l].apiKey=u,d[l].baseUrl||!e.aiAudioBaseUrl||(d[l].baseUrl=e.aiAudioBaseUrl)),{...c,...e,aiLLMProviders:{...t,...e.aiLLMProviders||{}},aiImageProviders:{...a,...e.aiImageProviders||{}},aiVideoProviders:{...o,...e.aiVideoProviders||{}},aiAudioProviders:{...d,...e.aiAudioProviders||{}},shippingZones:e.shippingZones||c.shippingZones,frontendContent:{...c.frontendContent,...e.frontendContent||{}}}}function m(){try{if(i().existsSync(p)){let e=i().readFileSync(p,"utf-8").replace(/^\uFEFF/,"").trim();return E(JSON.parse(e))}}catch{}return null}function T(){return"sqlite"===(process.env.DATABASE_BACKEND||"json")}let g=!1;function f(){return(0,l.hi)("settings",p,()=>{if(T())try{let e=r(20351).TM(),t=e?.settings?.get?.();if(t&&"object"==typeof t&&Object.keys(t).length>0){if(!g)return g=!0,function(e){let t=m();if(!t)return e;let a=!1,i={...e};for(let r of Object.keys(t)){let s=t[r];if(void 0===s)continue;let o=e[r];(null==o||""===o)&&(i[r]=s,a=!0)}if(a)try{let e=r(20351).TM();e?.settings?.update?.(i)}catch(e){console.warn("[Settings] Converge write failed:",e)}return i}(t);return t}}catch(e){console.warn("[Settings] SQLite read failed, falling back to JSON:",e)}return m()||c},l.U_.settings)}function h(e){if(i().existsSync(u)||i().mkdirSync(u,{recursive:!0}),T())try{let t=r(20351).TM(),a=t?.settings?.update?.(e);if(a&&"object"==typeof a)return i().writeFileSync(p,JSON.stringify(a,null,2),"utf-8"),(0,l.gm)("settings"),a}catch(e){console.warn("[Settings] SQLite save failed, falling back to JSON:",e)}let t=f(),a={...t,...e,frontendContent:e.frontendContent?{...t.frontendContent,...e.frontendContent}:t.frontendContent};return i().writeFileSync(p,JSON.stringify(a,null,2),"utf-8"),(0,l.gm)("settings"),a}function y(e){return f().shippingZones.find(t=>t.countries.some(t=>t.toLowerCase()===e.toLowerCase()))}function I(e,t){let r=t||d().randomBytes(16).toString("hex");return{hash:d().pbkdf2Sync(e,r,21e4,64,"sha512").toString("hex"),salt:r}}function S(e,t){let r=Buffer.from(e),a=Buffer.from(t);return r.length===a.length&&d().timingSafeEqual(r,a)}function A(e,t){return t.passwordHash&&t.salt?!!(S(I(e,t.salt).hash,t.passwordHash)||S(d().pbkdf2Sync(e,t.salt,1e5,64,"sha512").toString("hex"),t.passwordHash))||S(d().pbkdf2Sync(e,t.salt,1e3,64,"sha512").toString("hex"),t.passwordHash):!!t.password&&S(e,t.password)}function N(e,t){let r=y(e);if(!r){let e=f().shippingZones.find(e=>e.countries.includes("Other"));return{cost:e?t>=e.freeThreshold?0:e.baseCost:34.72,estimatedDays:e?`${e.estimatedDaysMin}-${e.estimatedDaysMax}`:"14-21",zone:e}}return{cost:t>=r.freeThreshold?0:r.baseCost,estimatedDays:`${r.estimatedDaysMin}-${r.estimatedDaysMax}`,zone:r}}},22831:(e,t,r)=>{r.r(t),r.d(t,{addUserAddress:()=>S,createUser:()=>g,findUserByEmail:()=>f,findUserById:()=>h,findUserByToken:()=>R,generateToken:()=>L,getAllUsers:()=>y,hashPassword:()=>m,needsPasswordRehash:()=>v,removeUserAddress:()=>A,setUserToken:()=>O,toPublicUser:()=>N,updateUser:()=>I,verifyPassword:()=>b});var a=r(29021),i=r.n(a),s=r(33873),o=r.n(s),n=r(55511),d=r.n(n),l=r(51105);let u=o().join(process.cwd(),"data"),p=o().join(u,"users.json");function c(){return i().existsSync(u)||i().mkdirSync(u,{recursive:!0}),i().existsSync(p)||i().writeFileSync(p,"[]","utf-8"),(0,l.hi)("users",p,()=>JSON.parse(i().readFileSync(p,"utf-8").replace(/^\uFEFF/,"").trim()),l.U_.users)}function E(e){i().writeFileSync(p,JSON.stringify(e,null,2),"utf-8"),(0,l.gm)("users")}function m(e,t){let r=t||d().randomBytes(16).toString("hex");return{hash:d().pbkdf2Sync(e,r,21e4,64,"sha512").toString("hex"),salt:r}}function T(e,t){let r=Buffer.from(e),a=Buffer.from(t);return r.length===a.length&&d().timingSafeEqual(r,a)}function g(e){let{hash:t,salt:r}=m(e.password),a=L(),i={id:"USR-"+Date.now().toString(36).toUpperCase()+"-"+Math.random().toString(36).slice(2,6).toUpperCase(),email:e.email.toLowerCase().trim(),passwordHash:t,salt:r,firstName:e.firstName,lastName:e.lastName,phone:"",addresses:[],token:a,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()},s=c();return s.push(i),E(s),i}function f(e){return c().find(t=>t.email===e.toLowerCase().trim())}function h(e){return c().find(t=>t.id===e)}function y(){return c()}function I(e,t){let r=c(),a=r.findIndex(t=>t.id===e);return -1===a?null:(r[a]={...r[a],...t,id:r[a].id,updatedAt:new Date().toISOString()},E(r),r[a])}function S(e,t){let r=c(),a=r.findIndex(t=>t.id===e);if(-1===a)return null;let i={...t,id:"ADDR-"+Date.now().toString(36).toUpperCase()};return i.isDefault&&r[a].addresses.forEach(e=>e.isDefault=!1),r[a].addresses.push(i),r[a].updatedAt=new Date().toISOString(),E(r),i}function A(e,t){let r=c(),a=r.findIndex(t=>t.id===e);if(-1===a)return!1;let i=r[a].addresses.findIndex(e=>e.id===t);return -1!==i&&(r[a].addresses.splice(i,1),r[a].updatedAt=new Date().toISOString(),E(r),!0)}function N(e){return{id:e.id,email:e.email,firstName:e.firstName,lastName:e.lastName,phone:e.phone,avatar:e.avatar,dob:e.dob,gender:e.gender,bio:e.bio,preferredCurrency:e.preferredCurrency,addresses:e.addresses,coupons:e.coupons,createdAt:e.createdAt}}function b(e,t,r){return!!(T(m(e,r).hash,t)||T(d().pbkdf2Sync(e,r,1e5,64,"sha512").toString("hex"),t))||T(d().pbkdf2Sync(e,r,1e3,64,"sha512").toString("hex"),t)}function v(e){return!1}function L(){return d().randomUUID()}function R(e){if(!e||e.length<16)return;let t=c().find(t=>t.token&&T(t.token,e));if(!(t&&t.tokenExpiresAt&&new Date(t.tokenExpiresAt).getTime()<Date.now()))return t}function O(e,t){let r=c(),a=r.findIndex(t=>t.id===e);-1!==a&&(r[a].token=t,E(r))}},60221:(e,t,r)=>{r.r(t),r.d(t,{addLog:()=>p,getAllLogs:()=>u,getLogStats:()=>m,getLogsByOperator:()=>c,getLogsByOrder:()=>E});var a=r(29021),i=r.n(a),s=r(33873),o=r.n(s),n=r(51105);let d=o().join(process.cwd(),"data"),l=o().join(d,"work-log.json");function u(){return i().existsSync(d)||i().mkdirSync(d,{recursive:!0}),i().existsSync(l)||i().writeFileSync(l,"[]","utf-8"),(0,n.hi)("work-log",l,()=>{let e=i().readFileSync(l,"utf-8").replace(/^\uFEFF/,"").trim();try{return JSON.parse(e)}catch{return[]}},n.U_.messages)}function p(e){let t=u(),r={id:"WL-"+Date.now().toString(36).toUpperCase()+"-"+Math.random().toString(36).slice(2,6).toUpperCase(),timestamp:new Date().toISOString(),...e};t.unshift(r);let a=t.slice(0,1e3);return i().writeFileSync(l,JSON.stringify(a,null,2),"utf-8"),(0,n.gm)("work-log"),r}function c(e){return u().filter(t=>t.operatorId===e)}function E(e){return u().filter(t=>t.orderId===e)}function m(){let e=u(),t=new Map;e.forEach(e=>{let r=e.operatorId;t.has(r)||t.set(r,{name:e.operatorName,count:0,role:e.operatorRole}),t.get(r).count++});let r=new Map;return e.forEach(e=>{r.set(e.action,(r.get(e.action)||0)+1)}),{total:e.length,operators:Array.from(t.entries()).map(([e,t])=>({id:e,...t})),actions:Array.from(r.entries()).map(([e,t])=>({action:e,count:t}))}}}};